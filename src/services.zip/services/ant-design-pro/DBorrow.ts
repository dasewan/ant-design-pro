// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get tab statistic. Get all DBorrow GET /admin/v1/d-borrow/tab */
export async function getAdminV1DBorrowTab(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowTabParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.CommonTab[]; total?: number; message?: string }>(
    '/admin/v1/d-borrow/tab',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows */
export async function getAdminV1DBorrows(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created DBorrow in storage Store DBorrow POST /admin/v1/d-borrows */
export async function postAdminV1DBorrows(body: API.DBorrow, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.DBorrow; message?: string }>(
    '/admin/v1/d-borrows',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows-cleared */
export async function getAdminV1DBorrowsCleared(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsClearedParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-cleared',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows-closed */
export async function getAdminV1DBorrowsClosed(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsClosedParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-closed',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows-outstanding */
export async function getAdminV1DBorrowsOutstanding(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsOutstandingParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-outstanding',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows-overdue */
export async function getAdminV1DBorrowsOverdue(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsOverdueParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-overdue',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the queue loan DBorrows. Get all DBorrows GET /admin/v1/d-borrows-queue-loan */
export async function getAdminV1DBorrowsQueueLoan(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsQueueLoanParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-queue-loan',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows-rejected */
export async function getAdminV1DBorrowsRejected(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsRejectedParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-rejected',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the DBorrows. Get all DBorrows GET /admin/v1/d-borrows-waiting-loan */
export async function getAdminV1DBorrowsWaitingLoan(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsWaitingLoanParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow[]; total?: number; message?: string }>(
    '/admin/v1/d-borrows-waiting-loan',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Display the specified DBorrow Get DBorrow GET /admin/v1/d-borrows/${param0} */
export async function getAdminV1DBorrowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBorrowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.DBorrow;
    other?: API.BorrowDetail;
    message?: string;
  }>(`/admin/v1/d-borrows/${param0}`, {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Update the specified DBorrow in storage Update DBorrow PUT /admin/v1/d-borrows/${param0} */
export async function putAdminV1DBorrowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1DBorrowsIdParams,
  body: API.DBorrow,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBorrow; message?: string }>(
    `/admin/v1/d-borrows/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified DBorrow from storage Delete DBorrow DELETE /admin/v1/d-borrows/${param0} */
export async function deleteAdminV1DBorrowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1DBorrowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/d-borrows/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
