// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GAMarketingDetails. Get all GAMarketingDetails GET /admin/v1/g-a-marketing-details */
export async function getAdminV1GAMarketingDetails(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GAMarketingDetailsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GAMarketingDetail[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-a-marketing-details', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created GAMarketingDetail in storage Store GAMarketingDetail POST /admin/v1/g-a-marketing-details */
export async function postAdminV1GAMarketingDetails(
  body: API.GAMarketingDetail,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GAMarketingDetail; message?: string }>(
    '/admin/v1/g-a-marketing-details',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GAMarketingDetail Get GAMarketingDetail GET /admin/v1/g-a-marketing-details/${param0} */
export async function getAdminV1GAMarketingDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GAMarketingDetailsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GAMarketingDetail; message?: string }>(
    `/admin/v1/g-a-marketing-details/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GAMarketingDetail in storage Update GAMarketingDetail PUT /admin/v1/g-a-marketing-details/${param0} */
export async function putAdminV1GAMarketingDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GAMarketingDetailsIdParams,
  body: API.GAMarketingDetail,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GAMarketingDetail; message?: string }>(
    `/admin/v1/g-a-marketing-details/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GAMarketingDetail from storage Delete GAMarketingDetail DELETE /admin/v1/g-a-marketing-details/${param0} */
export async function deleteAdminV1GAMarketingDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GAMarketingDetailsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-a-marketing-details/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get tab statistic. Get all GAMarketingDetail GET /admin/v1/g-a-marketing-details/tab */
export async function getAdminV1GAMarketingDetailsTab(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GAMarketingDetailsTabParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.CommonTab[]; total?: number; message?: string }>(
    '/admin/v1/g-a-marketing-details/tab',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
