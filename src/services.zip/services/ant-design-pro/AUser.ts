// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the AUsers. Get all AUsers GET /admin/v1/aUsers */
export async function getAdminV1AUsers(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AUsersParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.AUser[];
    aFChannels?: API.AFChannel[];
    total?: number;
    message?: string;
  }>('/admin/v1/aUsers', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created AUser in storage Store AUser POST /admin/v1/aUsers */
export async function postAdminV1AUsers(body: API.AUser, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.AUser; message?: string }>('/admin/v1/aUsers', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified AUser Get AUser GET /admin/v1/aUsers/${param0} */
export async function getAdminV1AUsersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AUsersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.AUser;
    aBCreditHistorys?: API.ABCreditHistory[];
    dBorrows?: API.DBorrow[];
    aCUserNews?: API.ACUserNew[];
    message?: string;
  }>(`/admin/v1/aUsers/${param0}`, {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Update the specified AUser in storage Update AUser PUT /admin/v1/aUsers/${param0} */
export async function putAdminV1AUsersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1AUsersIdParams,
  body: API.AUser,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AUser; message?: string }>(
    `/admin/v1/aUsers/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified AUser from storage Delete AUser DELETE /admin/v1/aUsers/${param0} */
export async function deleteAdminV1AUsersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1AUsersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/aUsers/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
