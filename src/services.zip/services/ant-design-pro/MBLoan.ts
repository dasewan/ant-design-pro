// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the Users. Get all AOLoanBank GET /admin/v1/banks-enum */
export async function getAdminV1BanksEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BanksEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AOLoanBank[]; total?: number; message?: string }>(
    '/admin/v1/banks-enum',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the MBLoans. Get all MBLoans GET /admin/v1/m-b-failed-loans */
export async function getAdminV1MBFailedLoans(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MBFailedLoansParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MBLoan[]; total?: number; message?: string }>(
    '/admin/v1/m-b-failed-loans',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the MBLoans. Get all MBLoans GET /admin/v1/m-b-intercept-loans */
export async function getAdminV1MBInterceptLoans(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MBInterceptLoansParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MBLoan[]; total?: number; message?: string }>(
    '/admin/v1/m-b-intercept-loans',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get tab statistic. Get all Loan GET /admin/v1/m-b-loan/tab */
export async function getAdminV1MBLoanTab(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MBLoanTabParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.CommonTab[]; total?: number; message?: string }>(
    '/admin/v1/m-b-loan/tab',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the MBLoans. Get all MBLoans GET /admin/v1/m-b-loans */
export async function getAdminV1MBLoans(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MBLoansParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MBLoan[]; total?: number; message?: string }>(
    '/admin/v1/m-b-loans',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created MBLoan in storage Store MBLoan POST /admin/v1/m-b-loans */
export async function postAdminV1MBLoans(body: API.MBLoan, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.MBLoan; message?: string }>(
    '/admin/v1/m-b-loans',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified MBLoan Get MBLoan GET /admin/v1/m-b-loans/${param0} */
export async function getAdminV1MBLoansId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MBLoansIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MBLoan; message?: string }>(
    `/admin/v1/m-b-loans/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified MBLoan in storage Update MBLoan PUT /admin/v1/m-b-loans/${param0} */
export async function putAdminV1MBLoansId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1MBLoansIdParams,
  body: API.MBLoan,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MBLoan; message?: string }>(
    `/admin/v1/m-b-loans/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified MBLoan from storage Delete MBLoan DELETE /admin/v1/m-b-loans/${param0} */
export async function deleteAdminV1MBLoansId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1MBLoansIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/m-b-loans/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
