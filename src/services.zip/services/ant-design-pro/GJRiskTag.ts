// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GJRiskTags. Get all GJRiskTags GET /admin/v1/g-j-risk-tags */
export async function getAdminV1GJRiskTags(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GJRiskTagsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GJRiskTag[]; total?: number; message?: string }>(
    '/admin/v1/g-j-risk-tags',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GJRiskTag in storage Store GJRiskTag POST /admin/v1/g-j-risk-tags */
export async function postAdminV1GJRiskTags(body: API.GJRiskTag, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.GJRiskTag; message?: string }>(
    '/admin/v1/g-j-risk-tags',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the GJRiskTag. Get all GJRiskTag GET /admin/v1/g-j-risk-tags-enums */
export async function getAdminV1GJRiskTagsEnums(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GJRiskTagsEnumsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GJRiskTag[]; total?: number; message?: string }>(
    '/admin/v1/g-j-risk-tags-enums',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Display the specified GJRiskTag Get GJRiskTag GET /admin/v1/g-j-risk-tags/${param0} */
export async function getAdminV1GJRiskTagsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GJRiskTagsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GJRiskTag; message?: string }>(
    `/admin/v1/g-j-risk-tags/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GJRiskTag in storage Update GJRiskTag PUT /admin/v1/g-j-risk-tags/${param0} */
export async function putAdminV1GJRiskTagsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GJRiskTagsIdParams,
  body: API.GJRiskTag,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GJRiskTag; message?: string }>(
    `/admin/v1/g-j-risk-tags/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GJRiskTag from storage Delete GJRiskTag DELETE /admin/v1/g-j-risk-tags/${param0} */
export async function deleteAdminV1GJRiskTagsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GJRiskTagsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-j-risk-tags/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
