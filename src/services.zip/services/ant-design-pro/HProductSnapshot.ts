// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the HProductSnapshots. Get all HProductSnapshots GET /admin/v1/h-product-snapshots */
export async function getAdminV1HProductSnapshots(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HProductSnapshotsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.HProductSnapshot[];
    total?: number;
    message?: string;
  }>('/admin/v1/h-product-snapshots', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created HProductSnapshot in storage Store HProductSnapshot POST /admin/v1/h-product-snapshots */
export async function postAdminV1HProductSnapshots(
  body: API.HProductSnapshot,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.HProductSnapshot; message?: string }>(
    '/admin/v1/h-product-snapshots',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified HProductSnapshot Get HProductSnapshot GET /admin/v1/h-product-snapshots/${param0} */
export async function getAdminV1HProductSnapshotsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HProductSnapshotsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HProductSnapshot; message?: string }>(
    `/admin/v1/h-product-snapshots/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified HProductSnapshot in storage Update HProductSnapshot PUT /admin/v1/h-product-snapshots/${param0} */
export async function putAdminV1HProductSnapshotsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1HProductSnapshotsIdParams,
  body: API.HProductSnapshot,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HProductSnapshot; message?: string }>(
    `/admin/v1/h-product-snapshots/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified HProductSnapshot from storage Delete HProductSnapshot DELETE /admin/v1/h-product-snapshots/${param0} */
export async function deleteAdminV1HProductSnapshotsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1HProductSnapshotsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/h-product-snapshots/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
