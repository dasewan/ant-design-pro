// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GGRiskStrateys. Get all GGRiskStrateys GET /admin/v1/g-g-risk-strateies */
export async function getAdminV1GGRiskStrateies(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GGRiskStrateiesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GGRiskStratey[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-g-risk-strateies', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created GGRiskStratey in storage Store GGRiskStratey POST /admin/v1/g-g-risk-strateies */
export async function postAdminV1GGRiskStrateies(
  body: API.GGRiskStratey,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GGRiskStratey; message?: string }>(
    '/admin/v1/g-g-risk-strateies',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the GGRiskStratey. Get all GGRiskStratey GET /admin/v1/g-g-risk-strateies-enums */
export async function getAdminV1GGRiskStrateiesEnums(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GGRiskStrateiesEnumsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GGRiskStratey[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-g-risk-strateies-enums', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Get a listing of the GGRiskStratey. Get all GGRiskStratey GET /admin/v1/g-g-risk-strateies-enums2 */
export async function getAdminV1GGRiskStrateiesEnums2(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GGRiskStrateiesEnums2Params,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GGRiskStratey[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-g-risk-strateies-enums2', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Display the specified GGRiskStratey Get GGRiskStratey GET /admin/v1/g-g-risk-strateies/${param0} */
export async function getAdminV1GGRiskStrateiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GGRiskStrateiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GGRiskStratey[]; message?: string }>(
    `/admin/v1/g-g-risk-strateies/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GGRiskStratey in storage Update GGRiskStratey PUT /admin/v1/g-g-risk-strateies/${param0} */
export async function putAdminV1GGRiskStrateiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GGRiskStrateiesIdParams,
  body: API.GGRiskStratey,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GGRiskStratey; message?: string }>(
    `/admin/v1/g-g-risk-strateies/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GGRiskStratey from storage Delete GGRiskStratey DELETE /admin/v1/g-g-risk-strateies/${param0} */
export async function deleteAdminV1GGRiskStrateiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GGRiskStrateiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-g-risk-strateies/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
