// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BKCollectionRoles. Get all BKCollectionRoles GET /admin/v1/b-k-collection-roles */
export async function getAdminV1BKCollectionRoles(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BKCollectionRolesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BKCollectionRole[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-k-collection-roles', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BKCollectionRole in storage Store BKCollectionRole POST /admin/v1/b-k-collection-roles */
export async function postAdminV1BKCollectionRoles(
  body: API.BKCollectionRole,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BKCollectionRole; message?: string }>(
    '/admin/v1/b-k-collection-roles',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BKCollectionRole Get BKCollectionRole GET /admin/v1/b-k-collection-roles/${param0} */
export async function getAdminV1BKCollectionRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BKCollectionRolesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BKCollectionRole; message?: string }>(
    `/admin/v1/b-k-collection-roles/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BKCollectionRole in storage Update BKCollectionRole PUT /admin/v1/b-k-collection-roles/${param0} */
export async function putAdminV1BKCollectionRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BKCollectionRolesIdParams,
  body: API.BKCollectionRole,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BKCollectionRole; message?: string }>(
    `/admin/v1/b-k-collection-roles/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BKCollectionRole from storage Delete BKCollectionRole DELETE /admin/v1/b-k-collection-roles/${param0} */
export async function deleteAdminV1BKCollectionRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BKCollectionRolesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-k-collection-roles/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
