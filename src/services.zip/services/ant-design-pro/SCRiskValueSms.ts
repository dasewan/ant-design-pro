// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the SCRiskValueSms. Get all SCRiskValueSms GET /admin/v1/s-c-risk-value-sms */
export async function getAdminV1SCRiskValueSms(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1SCRiskValueSmsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.SCRiskValueSms[];
    total?: number;
    message?: string;
  }>('/admin/v1/s-c-risk-value-sms', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created SCRiskValueSms in storage Store SCRiskValueSms POST /admin/v1/s-c-risk-value-sms */
export async function postAdminV1SCRiskValueSms(
  body: API.SCRiskValueSms,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.SCRiskValueSms; message?: string }>(
    '/admin/v1/s-c-risk-value-sms',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified SCRiskValueSms Get SCRiskValueSms GET /admin/v1/s-c-risk-value-sms/${param0} */
export async function getAdminV1SCRiskValueSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1SCRiskValueSmsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.SCRiskValueSms; message?: string }>(
    `/admin/v1/s-c-risk-value-sms/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified SCRiskValueSms in storage Update SCRiskValueSms PUT /admin/v1/s-c-risk-value-sms/${param0} */
export async function putAdminV1SCRiskValueSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1SCRiskValueSmsIdParams,
  body: API.SCRiskValueSms,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.SCRiskValueSms; message?: string }>(
    `/admin/v1/s-c-risk-value-sms/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified SCRiskValueSms from storage Delete SCRiskValueSms DELETE /admin/v1/s-c-risk-value-sms/${param0} */
export async function deleteAdminV1SCRiskValueSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1SCRiskValueSmsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/s-c-risk-value-sms/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
