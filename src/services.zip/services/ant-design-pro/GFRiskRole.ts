// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GFRiskRoles. Get all GFRiskRoles GET /admin/v1/g-f-risk-roles */
export async function getAdminV1GFRiskRoles(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GFRiskRolesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GFRiskRole[]; total?: number; message?: string }>(
    '/admin/v1/g-f-risk-roles',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GFRiskRole in storage Store GFRiskRole POST /admin/v1/g-f-risk-roles */
export async function postAdminV1GFRiskRoles(
  body: API.GFRiskRole,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GFRiskRole; message?: string }>(
    '/admin/v1/g-f-risk-roles',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GFRiskRole Get GFRiskRole GET /admin/v1/g-f-risk-roles/${param0} */
export async function getAdminV1GFRiskRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GFRiskRolesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GFRiskRole; message?: string }>(
    `/admin/v1/g-f-risk-roles/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GFRiskRole in storage Update GFRiskRole PUT /admin/v1/g-f-risk-roles/${param0} */
export async function putAdminV1GFRiskRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GFRiskRolesIdParams,
  body: API.GFRiskRole,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GFRiskRole; message?: string }>(
    `/admin/v1/g-f-risk-roles/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GFRiskRole from storage Delete GFRiskRole DELETE /admin/v1/g-f-risk-roles/${param0} */
export async function deleteAdminV1GFRiskRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GFRiskRolesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-f-risk-roles/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
