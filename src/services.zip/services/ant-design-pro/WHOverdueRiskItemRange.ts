// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WHOverdueRiskItemRanges. Get all WHOverdueRiskItemRanges GET /admin/v1/w-h-overdue-risk-item-ranges */
export async function getAdminV1WHOverdueRiskItemRanges(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WHOverdueRiskItemRangesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WHOverdueRiskItemRange[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-h-overdue-risk-item-ranges', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WHOverdueRiskItemRange in storage Store WHOverdueRiskItemRange POST /admin/v1/w-h-overdue-risk-item-ranges */
export async function postAdminV1WHOverdueRiskItemRanges(
  body: API.WHOverdueRiskItemRange,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WHOverdueRiskItemRange; message?: string }>(
    '/admin/v1/w-h-overdue-risk-item-ranges',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WHOverdueRiskItemRange Get WHOverdueRiskItemRange GET /admin/v1/w-h-overdue-risk-item-ranges/${param0} */
export async function getAdminV1WHOverdueRiskItemRangesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WHOverdueRiskItemRangesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WHOverdueRiskItemRange; message?: string }>(
    `/admin/v1/w-h-overdue-risk-item-ranges/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WHOverdueRiskItemRange in storage Update WHOverdueRiskItemRange PUT /admin/v1/w-h-overdue-risk-item-ranges/${param0} */
export async function putAdminV1WHOverdueRiskItemRangesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WHOverdueRiskItemRangesIdParams,
  body: API.WHOverdueRiskItemRange,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WHOverdueRiskItemRange; message?: string }>(
    `/admin/v1/w-h-overdue-risk-item-ranges/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WHOverdueRiskItemRange from storage Delete WHOverdueRiskItemRange DELETE /admin/v1/w-h-overdue-risk-item-ranges/${param0} */
export async function deleteAdminV1WHOverdueRiskItemRangesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WHOverdueRiskItemRangesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-h-overdue-risk-item-ranges/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
