// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WJRiskStrategies. Get all WJRiskStrategies GET /admin/v1/w-j-risk-strategies */
export async function getAdminV1WJRiskStrategies(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WJRiskStrategiesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WJRiskStrategy[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-j-risk-strategies', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WJRiskStrategy in storage Store WJRiskStrategy POST /admin/v1/w-j-risk-strategies */
export async function postAdminV1WJRiskStrategies(
  body: API.WJRiskStrategy,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WJRiskStrategy; message?: string }>(
    '/admin/v1/w-j-risk-strategies',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the WJRiskStrategies. Get all WJRiskStrategies GET /admin/v1/w-j-risk-strategies-index2 */
export async function getAdminV1WJRiskStrategiesIndex2(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WJRiskStrategiesIndex2Params,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WJRiskStrategy; message?: string }>(
    '/admin/v1/w-j-risk-strategies-index2',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Display the specified WJRiskStrategy Get WJRiskStrategy GET /admin/v1/w-j-risk-strategies/${param0} */
export async function getAdminV1WJRiskStrategiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WJRiskStrategiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WJRiskStrategy; message?: string }>(
    `/admin/v1/w-j-risk-strategies/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WJRiskStrategy in storage Update WJRiskStrategy PUT /admin/v1/w-j-risk-strategies/${param0} */
export async function putAdminV1WJRiskStrategiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WJRiskStrategiesIdParams,
  body: API.WJRiskStrategy,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WJRiskStrategy; message?: string }>(
    `/admin/v1/w-j-risk-strategies/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WJRiskStrategy from storage Delete WJRiskStrategy DELETE /admin/v1/w-j-risk-strategies/${param0} */
export async function deleteAdminV1WJRiskStrategiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WJRiskStrategiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-j-risk-strategies/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
