// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the QCCollectionNews. Get all QCCollectionNews GET /admin/v1/q-c-collection-news */
export async function getAdminV1QCCollectionNews(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1QCCollectionNewsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.QCCollectionNews[];
    total?: number;
    message?: string;
  }>('/admin/v1/q-c-collection-news', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created QCCollectionNews in storage Store QCCollectionNews POST /admin/v1/q-c-collection-news */
export async function postAdminV1QCCollectionNews(
  body: API.QCCollectionNews,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.QCCollectionNews; message?: string }>(
    '/admin/v1/q-c-collection-news',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified QCCollectionNews Get QCCollectionNews GET /admin/v1/q-c-collection-news/${param0} */
export async function getAdminV1QCCollectionNewsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1QCCollectionNewsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.QCCollectionNews; message?: string }>(
    `/admin/v1/q-c-collection-news/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified QCCollectionNews in storage Update QCCollectionNews PUT /admin/v1/q-c-collection-news/${param0} */
export async function putAdminV1QCCollectionNewsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1QCCollectionNewsIdParams,
  body: API.QCCollectionNews,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.QCCollectionNews; message?: string }>(
    `/admin/v1/q-c-collection-news/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified QCCollectionNews from storage Delete QCCollectionNews DELETE /admin/v1/q-c-collection-news/${param0} */
export async function deleteAdminV1QCCollectionNewsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1QCCollectionNewsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/q-c-collection-news/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
