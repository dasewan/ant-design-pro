// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WLCollectionAdmins. Get all WLCollectionAdmins GET /admin/v1/w-l-collection-admins */
export async function getAdminV1WLCollectionAdmins(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WLCollectionAdminsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WLCollectionAdmin[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-l-collection-admins', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WLCollectionAdmin in storage Store WLCollectionAdmin POST /admin/v1/w-l-collection-admins */
export async function postAdminV1WLCollectionAdmins(
  body: API.WLCollectionAdmin,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WLCollectionAdmin; message?: string }>(
    '/admin/v1/w-l-collection-admins',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WLCollectionAdmin Get WLCollectionAdmin GET /admin/v1/w-l-collection-admins/${param0} */
export async function getAdminV1WLCollectionAdminsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WLCollectionAdminsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WLCollectionAdmin; message?: string }>(
    `/admin/v1/w-l-collection-admins/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WLCollectionAdmin in storage Update WLCollectionAdmin PUT /admin/v1/w-l-collection-admins/${param0} */
export async function putAdminV1WLCollectionAdminsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WLCollectionAdminsIdParams,
  body: API.WLCollectionAdmin,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WLCollectionAdmin; message?: string }>(
    `/admin/v1/w-l-collection-admins/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WLCollectionAdmin from storage Delete WLCollectionAdmin DELETE /admin/v1/w-l-collection-admins/${param0} */
export async function deleteAdminV1WLCollectionAdminsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WLCollectionAdminsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-l-collection-admins/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
