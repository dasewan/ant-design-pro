// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WFDailyReports. Get all WFDailyReports GET /admin/v1/w-f-daily-reports */
export async function getAdminV1WFDailyReports(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WFDailyReportsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WFDailyReport[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-f-daily-reports', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WFDailyReport in storage Store WFDailyReport POST /admin/v1/w-f-daily-reports */
export async function postAdminV1WFDailyReports(
  body: API.WFDailyReport,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WFDailyReport; message?: string }>(
    '/admin/v1/w-f-daily-reports',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WFDailyReport Get WFDailyReport GET /admin/v1/w-f-daily-reports/${param0} */
export async function getAdminV1WFDailyReportsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WFDailyReportsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WFDailyReport; message?: string }>(
    `/admin/v1/w-f-daily-reports/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WFDailyReport in storage Update WFDailyReport PUT /admin/v1/w-f-daily-reports/${param0} */
export async function putAdminV1WFDailyReportsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WFDailyReportsIdParams,
  body: API.WFDailyReport,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WFDailyReport; message?: string }>(
    `/admin/v1/w-f-daily-reports/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WFDailyReport from storage Delete WFDailyReport DELETE /admin/v1/w-f-daily-reports/${param0} */
export async function deleteAdminV1WFDailyReportsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WFDailyReportsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-f-daily-reports/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
