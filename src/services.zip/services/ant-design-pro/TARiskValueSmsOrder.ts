// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the TARiskValueSmsOrders. Get all TARiskValueSmsOrders GET /admin/v1/t-a-risk-value-sms-orders */
export async function getAdminV1TARiskValueSmsOrders(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TARiskValueSmsOrdersParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.TARiskValueSmsOrder[];
    total?: number;
    message?: string;
  }>('/admin/v1/t-a-risk-value-sms-orders', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created TARiskValueSmsOrder in storage Store TARiskValueSmsOrder POST /admin/v1/t-a-risk-value-sms-orders */
export async function postAdminV1TARiskValueSmsOrders(
  body: API.TARiskValueSmsOrder,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.TARiskValueSmsOrder; message?: string }>(
    '/admin/v1/t-a-risk-value-sms-orders',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified TARiskValueSmsOrder Get TARiskValueSmsOrder GET /admin/v1/t-a-risk-value-sms-orders/${param0} */
export async function getAdminV1TARiskValueSmsOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TARiskValueSmsOrdersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TARiskValueSmsOrder; message?: string }>(
    `/admin/v1/t-a-risk-value-sms-orders/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified TARiskValueSmsOrder in storage Update TARiskValueSmsOrder PUT /admin/v1/t-a-risk-value-sms-orders/${param0} */
export async function putAdminV1TARiskValueSmsOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1TARiskValueSmsOrdersIdParams,
  body: API.TARiskValueSmsOrder,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TARiskValueSmsOrder; message?: string }>(
    `/admin/v1/t-a-risk-value-sms-orders/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified TARiskValueSmsOrder from storage Delete TARiskValueSmsOrder DELETE /admin/v1/t-a-risk-value-sms-orders/${param0} */
export async function deleteAdminV1TARiskValueSmsOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1TARiskValueSmsOrdersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/t-a-risk-value-sms-orders/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
