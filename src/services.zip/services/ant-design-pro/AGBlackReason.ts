// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the AGBlackReasons. Get all AGBlackReasons GET /admin/v1/aGBlackReasons */
export async function getAdminV1AGBlackReasons(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AGBlackReasonsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.AGBlackReason[];
    total?: number;
    message?: string;
  }>('/admin/v1/aGBlackReasons', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created AGBlackReason in storage Store AGBlackReason POST /admin/v1/aGBlackReasons */
export async function postAdminV1AGBlackReasons(
  body: API.AGBlackReason,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.AGBlackReason; message?: string }>(
    '/admin/v1/aGBlackReasons',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified AGBlackReason Get AGBlackReason GET /admin/v1/aGBlackReasons/${param0} */
export async function getAdminV1AGBlackReasonsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AGBlackReasonsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AGBlackReason; message?: string }>(
    `/admin/v1/aGBlackReasons/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified AGBlackReason in storage Update AGBlackReason PUT /admin/v1/aGBlackReasons/${param0} */
export async function putAdminV1AGBlackReasonsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1AGBlackReasonsIdParams,
  body: API.AGBlackReason,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AGBlackReason; message?: string }>(
    `/admin/v1/aGBlackReasons/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified AGBlackReason from storage Delete AGBlackReason DELETE /admin/v1/aGBlackReasons/${param0} */
export async function deleteAdminV1AGBlackReasonsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1AGBlackReasonsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/aGBlackReasons/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
