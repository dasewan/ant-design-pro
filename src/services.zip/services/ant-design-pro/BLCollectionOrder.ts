// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BLCollectionOrders. Get all BLCollectionOrders GET /admin/v1/b-l-collection-orders */
export async function getAdminV1BLCollectionOrders(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BLCollectionOrdersParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BLCollectionOrder[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-l-collection-orders', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BLCollectionOrder in storage Store BLCollectionOrder POST /admin/v1/b-l-collection-orders */
export async function postAdminV1BLCollectionOrders(
  body: API.BLCollectionOrder,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BLCollectionOrder; message?: string }>(
    '/admin/v1/b-l-collection-orders',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BLCollectionOrder Get BLCollectionOrder GET /admin/v1/b-l-collection-orders/${param0} */
export async function getAdminV1BLCollectionOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BLCollectionOrdersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BLCollectionOrder; message?: string }>(
    `/admin/v1/b-l-collection-orders/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BLCollectionOrder in storage Update BLCollectionOrder PUT /admin/v1/b-l-collection-orders/${param0} */
export async function putAdminV1BLCollectionOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BLCollectionOrdersIdParams,
  body: API.BLCollectionOrder,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BLCollectionOrder; message?: string }>(
    `/admin/v1/b-l-collection-orders/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BLCollectionOrder from storage Delete BLCollectionOrder DELETE /admin/v1/b-l-collection-orders/${param0} */
export async function deleteAdminV1BLCollectionOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BLCollectionOrdersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-l-collection-orders/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
