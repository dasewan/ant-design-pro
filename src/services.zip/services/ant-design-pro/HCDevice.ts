// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the HCDevices. Get all HCDevices GET /admin/v1/h-c-devices */
export async function getAdminV1HCDevices(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HCDevicesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HCDevice[]; total?: number; message?: string }>(
    '/admin/v1/h-c-devices',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created HCDevice in storage Store HCDevice POST /admin/v1/h-c-devices */
export async function postAdminV1HCDevices(body: API.HCDevice, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.HCDevice; message?: string }>(
    '/admin/v1/h-c-devices',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified HCDevice Get HCDevice GET /admin/v1/h-c-devices/${param0} */
export async function getAdminV1HCDevicesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HCDevicesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HCDevice; message?: string }>(
    `/admin/v1/h-c-devices/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified HCDevice in storage Update HCDevice PUT /admin/v1/h-c-devices/${param0} */
export async function putAdminV1HCDevicesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1HCDevicesIdParams,
  body: API.HCDevice,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HCDevice; message?: string }>(
    `/admin/v1/h-c-devices/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified HCDevice from storage Delete HCDevice DELETE /admin/v1/h-c-devices/${param0} */
export async function deleteAdminV1HCDevicesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1HCDevicesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/h-c-devices/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
