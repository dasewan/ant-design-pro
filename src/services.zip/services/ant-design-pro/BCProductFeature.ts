// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BCProductFeatures. Get all BCProductFeatures GET /admin/v1/b-c-product-features */
export async function getAdminV1BCProductFeatures(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BCProductFeaturesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BCProductFeature[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-c-product-features', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BCProductFeature in storage Store BCProductFeature POST /admin/v1/b-c-product-features */
export async function postAdminV1BCProductFeatures(
  body: API.BCProductFeature,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BCProductFeature; message?: string }>(
    '/admin/v1/b-c-product-features',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BCProductFeature Get BCProductFeature GET /admin/v1/b-c-product-features/${param0} */
export async function getAdminV1BCProductFeaturesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BCProductFeaturesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BCProductFeature; message?: string }>(
    `/admin/v1/b-c-product-features/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BCProductFeature in storage Update BCProductFeature PUT /admin/v1/b-c-product-features/${param0} */
export async function putAdminV1BCProductFeaturesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BCProductFeaturesIdParams,
  body: API.BCProductFeature,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BCProductFeature; message?: string }>(
    `/admin/v1/b-c-product-features/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BCProductFeature from storage Delete BCProductFeature DELETE /admin/v1/b-c-product-features/${param0} */
export async function deleteAdminV1BCProductFeaturesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BCProductFeaturesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-c-product-features/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
