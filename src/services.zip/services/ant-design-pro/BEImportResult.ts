// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BEImportResults. Get all BEImportResults GET /admin/v1/b-e-import-results */
export async function getAdminV1BEImportResults(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BEImportResultsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BEImportResult[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-e-import-results', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BEImportResult in storage Store BEImportResult POST /admin/v1/b-e-import-results */
export async function postAdminV1BEImportResults(
  body: API.BEImportResult,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BEImportResult; message?: string }>(
    '/admin/v1/b-e-import-results',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BEImportResult Get BEImportResult GET /admin/v1/b-e-import-results/${param0} */
export async function getAdminV1BEImportResultsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BEImportResultsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BEImportResult; message?: string }>(
    `/admin/v1/b-e-import-results/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BEImportResult in storage Update BEImportResult PUT /admin/v1/b-e-import-results/${param0} */
export async function putAdminV1BEImportResultsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BEImportResultsIdParams,
  body: API.BEImportResult,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BEImportResult; message?: string }>(
    `/admin/v1/b-e-import-results/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BEImportResult from storage Delete BEImportResult DELETE /admin/v1/b-e-import-results/${param0} */
export async function deleteAdminV1BEImportResultsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BEImportResultsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-e-import-results/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
