// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the RCSms. Get all RCSms GET /admin/v1/r-c-sms */
export async function getAdminV1RCSms(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1RCSmsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.RCSms[]; total?: number; message?: string }>(
    '/admin/v1/r-c-sms',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created RCSms in storage Store RCSms POST /admin/v1/r-c-sms */
export async function postAdminV1RCSms(body: API.RCSms, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.RCSms; message?: string }>('/admin/v1/r-c-sms', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified RCSms Get RCSms GET /admin/v1/r-c-sms/${param0} */
export async function getAdminV1RCSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1RCSmsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.RCSms; message?: string }>(
    `/admin/v1/r-c-sms/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified RCSms in storage Update RCSms PUT /admin/v1/r-c-sms/${param0} */
export async function putAdminV1RCSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1RCSmsIdParams,
  body: API.RCSms,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.RCSms; message?: string }>(
    `/admin/v1/r-c-sms/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified RCSms from storage Delete RCSms DELETE /admin/v1/r-c-sms/${param0} */
export async function deleteAdminV1RCSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1RCSmsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/r-c-sms/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
