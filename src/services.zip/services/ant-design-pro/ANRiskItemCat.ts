// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the ANRiskItemCat. Get all ANRiskItemCat GET /admin/v1/a-n-risk-item-cat-enums */
export async function getAdminV1ANRiskItemCatEnums(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ANRiskItemCatEnumsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.ANRiskItemCat[];
    total?: number;
    message?: string;
  }>('/admin/v1/a-n-risk-item-cat-enums', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Get a listing of the ANRiskItemCats. Get all ANRiskItemCats GET /admin/v1/a-n-risk-item-cats */
export async function getAdminV1ANRiskItemCats(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ANRiskItemCatsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.ANRiskItemCat[];
    total?: number;
    message?: string;
  }>('/admin/v1/a-n-risk-item-cats', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created ANRiskItemCat in storage Store ANRiskItemCat POST /admin/v1/a-n-risk-item-cats */
export async function postAdminV1ANRiskItemCats(
  body: API.ANRiskItemCat,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.ANRiskItemCat; message?: string }>(
    '/admin/v1/a-n-risk-item-cats',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified ANRiskItemCat Get ANRiskItemCat GET /admin/v1/a-n-risk-item-cats/${param0} */
export async function getAdminV1ANRiskItemCatsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ANRiskItemCatsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ANRiskItemCat; message?: string }>(
    `/admin/v1/a-n-risk-item-cats/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified ANRiskItemCat in storage Update ANRiskItemCat PUT /admin/v1/a-n-risk-item-cats/${param0} */
export async function putAdminV1ANRiskItemCatsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1ANRiskItemCatsIdParams,
  body: API.ANRiskItemCat,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ANRiskItemCat; message?: string }>(
    `/admin/v1/a-n-risk-item-cats/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified ANRiskItemCat from storage Delete ANRiskItemCat DELETE /admin/v1/a-n-risk-item-cats/${param0} */
export async function deleteAdminV1ANRiskItemCatsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1ANRiskItemCatsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/a-n-risk-item-cats/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
