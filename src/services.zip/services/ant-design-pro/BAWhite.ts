// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get tab statistic. Get all BAWhite GET /admin/v1/b-a-white/tab */
export async function getAdminV1BAWhiteTab(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BAWhiteTabParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.CommonTab[]; total?: number; message?: string }>(
    '/admin/v1/b-a-white/tab',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the BAWhites. Get all BAWhites GET /admin/v1/b-a-whites */
export async function getAdminV1BAWhites(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BAWhitesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BAWhite[]; total?: number; message?: string }>(
    '/admin/v1/b-a-whites',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created BAWhite in storage Store BAWhite POST /admin/v1/b-a-whites */
export async function postAdminV1BAWhites(body: API.BAWhite, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.BAWhite; message?: string }>(
    '/admin/v1/b-a-whites',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the BAWhites. Get all BAWhites GET /admin/v1/b-a-whites-users */
export async function getAdminV1BAWhitesUsers(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BAWhitesUsersParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BAWhite[]; total?: number; message?: string }>(
    '/admin/v1/b-a-whites-users',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Display the specified BAWhite Get BAWhite GET /admin/v1/b-a-whites/${param0} */
export async function getAdminV1BAWhitesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BAWhitesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BAWhite; message?: string }>(
    `/admin/v1/b-a-whites/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BAWhite in storage Update BAWhite PUT /admin/v1/b-a-whites/${param0} */
export async function putAdminV1BAWhitesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BAWhitesIdParams,
  body: API.BAWhite,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BAWhite; message?: string }>(
    `/admin/v1/b-a-whites/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BAWhite from storage Delete BAWhite DELETE /admin/v1/b-a-whites/${param0} */
export async function deleteAdminV1BAWhitesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BAWhitesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-a-whites/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created BAWhite in storage Store BAWhite POST /admin/v1/import */
export async function postAdminV1__openAPI__import(
  body: API.BAWhite,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BAWhite; message?: string }>('/admin/v1/import', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}
