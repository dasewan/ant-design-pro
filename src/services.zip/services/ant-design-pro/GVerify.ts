// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GVerifies. Get all GVerifies GET /admin/v1/g-verifies */
export async function getAdminV1GVerifies(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GVerifiesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GVerify[]; total?: number; message?: string }>(
    '/admin/v1/g-verifies',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GVerify in storage Store GVerify POST /admin/v1/g-verifies */
export async function postAdminV1GVerifies(body: API.GVerify, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.GVerify; message?: string }>(
    '/admin/v1/g-verifies',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GVerify Get GVerify GET /admin/v1/g-verifies/${param0} */
export async function getAdminV1GVerifiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GVerifiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GVerify; message?: string }>(
    `/admin/v1/g-verifies/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GVerify in storage Update GVerify PUT /admin/v1/g-verifies/${param0} */
export async function putAdminV1GVerifiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GVerifiesIdParams,
  body: API.GVerify,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GVerify; message?: string }>(
    `/admin/v1/g-verifies/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GVerify from storage Delete GVerify DELETE /admin/v1/g-verifies/${param0} */
export async function deleteAdminV1GVerifiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GVerifiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-verifies/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
