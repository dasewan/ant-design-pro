// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WNCollectionFlows. Get all WNCollectionFlows GET /admin/v1/w-n-collection-flows */
export async function getAdminV1WNCollectionFlows(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WNCollectionFlowsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WNCollectionFlow[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-n-collection-flows', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WNCollectionFlow in storage Store WNCollectionFlow POST /admin/v1/w-n-collection-flows */
export async function postAdminV1WNCollectionFlows(
  body: API.WNCollectionFlow,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WNCollectionFlow; message?: string }>(
    '/admin/v1/w-n-collection-flows',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WNCollectionFlow Get WNCollectionFlow GET /admin/v1/w-n-collection-flows/${param0} */
export async function getAdminV1WNCollectionFlowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WNCollectionFlowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WNCollectionFlow; message?: string }>(
    `/admin/v1/w-n-collection-flows/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WNCollectionFlow in storage Update WNCollectionFlow PUT /admin/v1/w-n-collection-flows/${param0} */
export async function putAdminV1WNCollectionFlowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WNCollectionFlowsIdParams,
  body: API.WNCollectionFlow,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WNCollectionFlow; message?: string }>(
    `/admin/v1/w-n-collection-flows/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WNCollectionFlow from storage Delete WNCollectionFlow DELETE /admin/v1/w-n-collection-flows/${param0} */
export async function deleteAdminV1WNCollectionFlowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WNCollectionFlowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-n-collection-flows/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
