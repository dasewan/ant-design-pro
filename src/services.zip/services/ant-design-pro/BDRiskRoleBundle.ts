// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BDRiskRoleBundles. Get all BDRiskRoleBundles GET /admin/v1/b-d-risk-role-bundles */
export async function getAdminV1BDRiskRoleBundles(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BDRiskRoleBundlesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BDRiskRoleBundle[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-d-risk-role-bundles', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BDRiskRoleBundle in storage Store BDRiskRoleBundle POST /admin/v1/b-d-risk-role-bundles */
export async function postAdminV1BDRiskRoleBundles(
  body: API.BDRiskRoleBundle,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BDRiskRoleBundle; message?: string }>(
    '/admin/v1/b-d-risk-role-bundles',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the riskitem. Get all BDRiskRoleBundle GET /admin/v1/b-d-risk-role-bundles-enum */
export async function getAdminV1BDRiskRoleBundlesEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BDRiskRoleBundlesEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BDRiskRoleBundle[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-d-risk-role-bundles-enum', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Display the specified BDRiskRoleBundle Get BDRiskRoleBundle GET /admin/v1/b-d-risk-role-bundles/${param0} */
export async function getAdminV1BDRiskRoleBundlesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BDRiskRoleBundlesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BDRiskRoleBundle[];
    total?: number;
    message?: string;
  }>(`/admin/v1/b-d-risk-role-bundles/${param0}`, {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Update the specified BDRiskRoleBundle in storage Update BDRiskRoleBundle PUT /admin/v1/b-d-risk-role-bundles/${param0} */
export async function putAdminV1BDRiskRoleBundlesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BDRiskRoleBundlesIdParams,
  body: API.BDRiskRoleBundle,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BDRiskRoleBundle; message?: string }>(
    `/admin/v1/b-d-risk-role-bundles/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BDRiskRoleBundle from storage Delete BDRiskRoleBundle DELETE /admin/v1/b-d-risk-role-bundles/${param0} */
export async function deleteAdminV1BDRiskRoleBundlesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BDRiskRoleBundlesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-d-risk-role-bundles/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
