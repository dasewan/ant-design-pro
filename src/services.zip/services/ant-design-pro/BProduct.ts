// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BProducts. Get all BProducts GET /admin/v1/b-products */
export async function getAdminV1BProducts(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BProductsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BProduct[]; total?: number; message?: string }>(
    '/admin/v1/b-products',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created BProduct in storage Store BProduct POST /admin/v1/b-products */
export async function postAdminV1BProducts(body: API.BProduct, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.BProduct; message?: string }>(
    '/admin/v1/b-products',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Update the specified BProduct sort in storage Update BProduct PUT /admin/v1/b-products-sort */
export async function putAdminV1BProductsSort(
  body: API.BProduct,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BProduct; message?: string }>(
    '/admin/v1/b-products-sort',
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BProduct Get BProduct GET /admin/v1/b-products/${param0} */
export async function getAdminV1BProductsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BProductsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BProduct; message?: string }>(
    `/admin/v1/b-products/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BProduct in storage Update BProduct PUT /admin/v1/b-products/${param0} */
export async function putAdminV1BProductsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BProductsIdParams,
  body: API.BProduct,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BProduct; message?: string }>(
    `/admin/v1/b-products/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BProduct from storage Delete BProduct DELETE /admin/v1/b-products/${param0} */
export async function deleteAdminV1BProductsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BProductsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-products/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the Products. Get all BProduct GET /admin/v1/products-enum */
export async function getAdminV1ProductsEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ProductsEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BProduct[]; total?: number; message?: string }>(
    '/admin/v1/products-enum',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
