// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the AHUserSups. Get all AHUserSups GET /aHUserSups */
export async function getAHUserSups(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAHUserSupsParams,
  options?: { [key: string]: any },
) {
  const { current: param0, pageSize: param1, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AHUserSup[]; total?: number; message?: string }>(
    '/aHUserSups',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created AHUserSup in storage Store AHUserSup POST /aHUserSups */
export async function postAHUserSups(body: API.AHUserSup, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.AHUserSup; message?: string }>('/aHUserSups', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified AHUserSup Get AHUserSup GET /aHUserSups/${param0} */
export async function getAHUserSupsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAHUserSupsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AHUserSup; message?: string }>(
    `/aHUserSups/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified AHUserSup in storage Update AHUserSup PUT /aHUserSups/${param0} */
export async function putAHUserSupsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAHUserSupsIdParams,
  body: API.AHUserSup,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AHUserSup; message?: string }>(
    `/aHUserSups/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified AHUserSup from storage Delete AHUserSup DELETE /aHUserSups/${param0} */
export async function deleteAHUserSupsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAHUserSupsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(`/aHUserSups/${param0}`, {
    method: 'DELETE',
    params: { ...queryParams },
    ...(options || {}),
  });
}
