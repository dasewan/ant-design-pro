// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GKBanks. Get all GKBanks GET /admin/v1/g-k-banks */
export async function getAdminV1GKBanks(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GKBanksParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GKBank[]; total?: number; message?: string }>(
    '/admin/v1/g-k-banks',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GKBank in storage Store GKBank POST /admin/v1/g-k-banks */
export async function postAdminV1GKBanks(body: API.GKBank, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.GKBank; message?: string }>(
    '/admin/v1/g-k-banks',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GKBank Get GKBank GET /admin/v1/g-k-banks/${param0} */
export async function getAdminV1GKBanksId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GKBanksIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GKBank; message?: string }>(
    `/admin/v1/g-k-banks/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GKBank in storage Update GKBank PUT /admin/v1/g-k-banks/${param0} */
export async function putAdminV1GKBanksId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GKBanksIdParams,
  body: API.GKBank,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GKBank; message?: string }>(
    `/admin/v1/g-k-banks/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GKBank from storage Delete GKBank DELETE /admin/v1/g-k-banks/${param0} */
export async function deleteAdminV1GKBanksId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GKBanksIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-k-banks/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
