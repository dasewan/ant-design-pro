// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WCProductLoanOverdues. Get all WCProductLoanOverdues GET /admin/v1/w-c-product-loan-overdues */
export async function getAdminV1WCProductLoanOverdues(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WCProductLoanOverduesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WCProductLoanOverdue[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-c-product-loan-overdues', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WCProductLoanOverdue in storage Store WCProductLoanOverdue POST /admin/v1/w-c-product-loan-overdues */
export async function postAdminV1WCProductLoanOverdues(
  body: API.WCProductLoanOverdue,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WCProductLoanOverdue; message?: string }>(
    '/admin/v1/w-c-product-loan-overdues',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WCProductLoanOverdue Get WCProductLoanOverdue GET /admin/v1/w-c-product-loan-overdues/${param0} */
export async function getAdminV1WCProductLoanOverduesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WCProductLoanOverduesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WCProductLoanOverdue; message?: string }>(
    `/admin/v1/w-c-product-loan-overdues/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WCProductLoanOverdue in storage Update WCProductLoanOverdue PUT /admin/v1/w-c-product-loan-overdues/${param0} */
export async function putAdminV1WCProductLoanOverduesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WCProductLoanOverduesIdParams,
  body: API.WCProductLoanOverdue,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WCProductLoanOverdue; message?: string }>(
    `/admin/v1/w-c-product-loan-overdues/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WCProductLoanOverdue from storage Delete WCProductLoanOverdue DELETE /admin/v1/w-c-product-loan-overdues/${param0} */
export async function deleteAdminV1WCProductLoanOverduesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WCProductLoanOverduesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-c-product-loan-overdues/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
