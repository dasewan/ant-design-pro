// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the DDRecallDetails. Get all DDRecallDetails GET /admin/v1/d-d-recall-details */
export async function getAdminV1DDRecallDetails(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DDRecallDetailsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.DDRecallDetail[];
    total?: number;
    message?: string;
  }>('/admin/v1/d-d-recall-details', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created DDRecallDetail in storage Store DDRecallDetail POST /admin/v1/d-d-recall-details */
export async function postAdminV1DDRecallDetails(
  body: API.DDRecallDetail,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.DDRecallDetail; message?: string }>(
    '/admin/v1/d-d-recall-details',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified DDRecallDetail Get DDRecallDetail GET /admin/v1/d-d-recall-details/${param0} */
export async function getAdminV1DDRecallDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DDRecallDetailsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DDRecallDetail; message?: string }>(
    `/admin/v1/d-d-recall-details/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified DDRecallDetail in storage Update DDRecallDetail PUT /admin/v1/d-d-recall-details/${param0} */
export async function putAdminV1DDRecallDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1DDRecallDetailsIdParams,
  body: API.DDRecallDetail,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DDRecallDetail; message?: string }>(
    `/admin/v1/d-d-recall-details/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified DDRecallDetail from storage Delete DDRecallDetail DELETE /admin/v1/d-d-recall-details/${param0} */
export async function deleteAdminV1DDRecallDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1DDRecallDetailsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/d-d-recall-details/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
