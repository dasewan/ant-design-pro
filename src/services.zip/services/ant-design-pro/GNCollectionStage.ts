// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GNCollectionStages. Get all GNCollectionStages GET /admin/v1/g-n-collection-stages */
export async function getAdminV1GNCollectionStages(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GNCollectionStagesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GNCollectionStage[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-n-collection-stages', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created GNCollectionStage in storage Store GNCollectionStage POST /admin/v1/g-n-collection-stages */
export async function postAdminV1GNCollectionStages(
  body: API.GNCollectionStage,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GNCollectionStage; message?: string }>(
    '/admin/v1/g-n-collection-stages',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the GNCollectionStage. Get all GNCollectionStage GET /admin/v1/g-n-collection-stages-enum */
export async function getAdminV1GNCollectionStagesEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GNCollectionStagesEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GNCollectionStage[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-n-collection-stages-enum', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Display the specified GNCollectionStage Get GNCollectionStage GET /admin/v1/g-n-collection-stages/${param0} */
export async function getAdminV1GNCollectionStagesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GNCollectionStagesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GNCollectionStage; message?: string }>(
    `/admin/v1/g-n-collection-stages/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GNCollectionStage in storage Update GNCollectionStage PUT /admin/v1/g-n-collection-stages/${param0} */
export async function putAdminV1GNCollectionStagesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GNCollectionStagesIdParams,
  body: API.GNCollectionStage,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GNCollectionStage; message?: string }>(
    `/admin/v1/g-n-collection-stages/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GNCollectionStage from storage Delete GNCollectionStage DELETE /admin/v1/g-n-collection-stages/${param0} */
export async function deleteAdminV1GNCollectionStagesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GNCollectionStagesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-n-collection-stages/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
