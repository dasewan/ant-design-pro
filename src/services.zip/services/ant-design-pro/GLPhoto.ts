// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GLPhotos. Get all GLPhotos GET /admin/v1/g-l-photos */
export async function getAdminV1GLPhotos(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GLPhotosParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GLPhoto[]; total?: number; message?: string }>(
    '/admin/v1/g-l-photos',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GLPhoto in storage Store GLPhoto POST /admin/v1/g-l-photos */
export async function postAdminV1GLPhotos(body: API.GLPhoto, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.GLPhoto; message?: string }>(
    '/admin/v1/g-l-photos',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GLPhoto Get GLPhoto GET /admin/v1/g-l-photos/${param0} */
export async function getAdminV1GLPhotosId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GLPhotosIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GLPhoto; message?: string }>(
    `/admin/v1/g-l-photos/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GLPhoto in storage Update GLPhoto PUT /admin/v1/g-l-photos/${param0} */
export async function putAdminV1GLPhotosId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GLPhotosIdParams,
  body: API.GLPhoto,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GLPhoto; message?: string }>(
    `/admin/v1/g-l-photos/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GLPhoto from storage Delete GLPhoto DELETE /admin/v1/g-l-photos/${param0} */
export async function deleteAdminV1GLPhotosId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GLPhotosIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-l-photos/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
