// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WAMarketings. Get all WAMarketings GET /admin/v1/w-a-marketings */
export async function getAdminV1WAMarketings(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WAMarketingsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WAMarketing[]; total?: number; message?: string }>(
    '/admin/v1/w-a-marketings',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created WAMarketing in storage Store WAMarketing POST /admin/v1/w-a-marketings */
export async function postAdminV1WAMarketings(
  body: API.WAMarketing,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WAMarketing; message?: string }>(
    '/admin/v1/w-a-marketings',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WAMarketing Get WAMarketing GET /admin/v1/w-a-marketings/${param0} */
export async function getAdminV1WAMarketingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WAMarketingsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WAMarketing; message?: string }>(
    `/admin/v1/w-a-marketings/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WAMarketing in storage Update WAMarketing PUT /admin/v1/w-a-marketings/${param0} */
export async function putAdminV1WAMarketingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WAMarketingsIdParams,
  body: API.WAMarketing,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WAMarketing; message?: string }>(
    `/admin/v1/w-a-marketings/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WAMarketing from storage Delete WAMarketing DELETE /admin/v1/w-a-marketings/${param0} */
export async function deleteAdminV1WAMarketingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WAMarketingsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-a-marketings/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
