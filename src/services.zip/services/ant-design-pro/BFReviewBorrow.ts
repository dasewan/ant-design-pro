// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BFReviewBorrows. Get all BFReviewBorrows GET /admin/v1/b-f-review-borrows */
export async function getAdminV1BFReviewBorrows(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BFReviewBorrowsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BFReviewBorrow[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-f-review-borrows', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BFReviewBorrow in storage Store BFReviewBorrow POST /admin/v1/b-f-review-borrows */
export async function postAdminV1BFReviewBorrows(
  body: API.BFReviewBorrow,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BFReviewBorrow; message?: string }>(
    '/admin/v1/b-f-review-borrows',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Update the specified BFReviewBorrow in storage Update BFReviewBorrow PUT /admin/v1/b-f-review-borrows-release */
export async function putAdminV1BFReviewBorrowsRelease(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BFReviewBorrowsReleaseParams,
  body: API.BFReviewBorrow,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BFReviewBorrow; message?: string }>(
    '/admin/v1/b-f-review-borrows-release',
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BFReviewBorrow Get BFReviewBorrow GET /admin/v1/b-f-review-borrows/${param0} */
export async function getAdminV1BFReviewBorrowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BFReviewBorrowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BFReviewBorrow; message?: string }>(
    `/admin/v1/b-f-review-borrows/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BFReviewBorrow in storage Update BFReviewBorrow PUT /admin/v1/b-f-review-borrows/${param0} */
export async function putAdminV1BFReviewBorrowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BFReviewBorrowsIdParams,
  body: API.BFReviewBorrow,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BFReviewBorrow; message?: string }>(
    `/admin/v1/b-f-review-borrows/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BFReviewBorrow from storage Delete BFReviewBorrow DELETE /admin/v1/b-f-review-borrows/${param0} */
export async function deleteAdminV1BFReviewBorrowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BFReviewBorrowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-f-review-borrows/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
