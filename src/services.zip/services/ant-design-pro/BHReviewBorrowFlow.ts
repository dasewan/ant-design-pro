// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BHReviewBorrowFlows. Get all BHReviewBorrowFlows GET /admin/v1/b-h-review-borrow-flows */
export async function getAdminV1BHReviewBorrowFlows(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BHReviewBorrowFlowsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BHReviewBorrowFlow[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-h-review-borrow-flows', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BHReviewBorrowFlow in storage Store BHReviewBorrowFlow POST /admin/v1/b-h-review-borrow-flows */
export async function postAdminV1BHReviewBorrowFlows(
  body: API.BHReviewBorrowFlow,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BHReviewBorrowFlow; message?: string }>(
    '/admin/v1/b-h-review-borrow-flows',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BHReviewBorrowFlow Get BHReviewBorrowFlow GET /admin/v1/b-h-review-borrow-flows/${param0} */
export async function getAdminV1BHReviewBorrowFlowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BHReviewBorrowFlowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BHReviewBorrowFlow; message?: string }>(
    `/admin/v1/b-h-review-borrow-flows/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BHReviewBorrowFlow in storage Update BHReviewBorrowFlow PUT /admin/v1/b-h-review-borrow-flows/${param0} */
export async function putAdminV1BHReviewBorrowFlowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BHReviewBorrowFlowsIdParams,
  body: API.BHReviewBorrowFlow,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BHReviewBorrowFlow; message?: string }>(
    `/admin/v1/b-h-review-borrow-flows/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BHReviewBorrowFlow from storage Delete BHReviewBorrowFlow DELETE /admin/v1/b-h-review-borrow-flows/${param0} */
export async function deleteAdminV1BHReviewBorrowFlowsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BHReviewBorrowFlowsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-h-review-borrow-flows/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
