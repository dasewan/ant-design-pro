// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WPBackFills. Get all WPBackFills GET /admin/v1/w-p-back-fills */
export async function getAdminV1WPBackFills(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WPBackFillsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WPBackFill[]; total?: number; message?: string }>(
    '/admin/v1/w-p-back-fills',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created WPBackFill in storage Store WPBackFill POST /admin/v1/w-p-back-fills */
export async function postAdminV1WPBackFills(
  body: API.WPBackFill,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WPBackFill; message?: string }>(
    '/admin/v1/w-p-back-fills',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WPBackFill Get WPBackFill GET /admin/v1/w-p-back-fills/${param0} */
export async function getAdminV1WPBackFillsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WPBackFillsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WPBackFill; message?: string }>(
    `/admin/v1/w-p-back-fills/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WPBackFill in storage Update WPBackFill PUT /admin/v1/w-p-back-fills/${param0} */
export async function putAdminV1WPBackFillsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WPBackFillsIdParams,
  body: API.WPBackFill,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WPBackFill; message?: string }>(
    `/admin/v1/w-p-back-fills/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WPBackFill from storage Delete WPBackFill DELETE /admin/v1/w-p-back-fills/${param0} */
export async function deleteAdminV1WPBackFillsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WPBackFillsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-p-back-fills/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
