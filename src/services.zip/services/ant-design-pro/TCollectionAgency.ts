// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the TCollectionAgencies. Get all TCollectionAgencies GET /admin/v1/t-collection-agencies */
export async function getAdminV1TCollectionAgencies(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TCollectionAgenciesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.TCollectionAgency[];
    total?: number;
    message?: string;
  }>('/admin/v1/t-collection-agencies', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created TCollectionAgency in storage Store TCollectionAgency POST /admin/v1/t-collection-agencies */
export async function postAdminV1TCollectionAgencies(
  body: API.TCollectionAgency,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.TCollectionAgency; message?: string }>(
    '/admin/v1/t-collection-agencies',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the TCollectionAgency. Get all TCollectionAgency GET /admin/v1/t-collection-agencies-enum */
export async function getAdminV1TCollectionAgenciesEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TCollectionAgenciesEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.TCollectionAgency[];
    total?: number;
    message?: string;
  }>('/admin/v1/t-collection-agencies-enum', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Display the specified TCollectionAgency Get TCollectionAgency GET /admin/v1/t-collection-agencies/${param0} */
export async function getAdminV1TCollectionAgenciesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TCollectionAgenciesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TCollectionAgency; message?: string }>(
    `/admin/v1/t-collection-agencies/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified TCollectionAgency in storage Update TCollectionAgency PUT /admin/v1/t-collection-agencies/${param0} */
export async function putAdminV1TCollectionAgenciesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1TCollectionAgenciesIdParams,
  body: API.TCollectionAgency,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TCollectionAgency; message?: string }>(
    `/admin/v1/t-collection-agencies/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified TCollectionAgency from storage Delete TCollectionAgency DELETE /admin/v1/t-collection-agencies/${param0} */
export async function deleteAdminV1TCollectionAgenciesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1TCollectionAgenciesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/t-collection-agencies/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
