// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Store a newly created ACUserNew in storage Store ACUserNew POST /aCUserNews */
export async function postACUserNews(body: API.ACUserNew, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.ACUserNew; message?: string }>('/aCUserNews', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified ACUserNew Get ACUserNew GET /aCUserNews/${param0} */
export async function getACUserNewsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getACUserNewsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ACUserNew; message?: string }>(
    `/aCUserNews/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified ACUserNew in storage Update ACUserNew PUT /aCUserNews/${param0} */
export async function putACUserNewsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putACUserNewsIdParams,
  body: API.ACUserNew,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ACUserNew; message?: string }>(
    `/aCUserNews/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified ACUserNew from storage Delete ACUserNew DELETE /aCUserNews/${param0} */
export async function deleteACUserNewsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteACUserNewsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(`/aCUserNews/${param0}`, {
    method: 'DELETE',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Get a listing of the ACUserNews. Get all ACUserNews GET /admin/v1/aCUserNews */
export async function getAdminV1ACUserNews(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ACUserNewsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ACUserNew[]; total?: number; message?: string }>(
    '/admin/v1/aCUserNews',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
