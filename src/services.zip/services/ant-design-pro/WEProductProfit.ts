// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WEProductProfits. Get all WEProductProfits GET /admin/v1/w-e-product-profits */
export async function getAdminV1WEProductProfits(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WEProductProfitsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WEProductProfit[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-e-product-profits', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WEProductProfit in storage Store WEProductProfit POST /admin/v1/w-e-product-profits */
export async function postAdminV1WEProductProfits(
  body: API.WEProductProfit,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WEProductProfit; message?: string }>(
    '/admin/v1/w-e-product-profits',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WEProductProfit Get WEProductProfit GET /admin/v1/w-e-product-profits/${param0} */
export async function getAdminV1WEProductProfitsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WEProductProfitsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WEProductProfit; message?: string }>(
    `/admin/v1/w-e-product-profits/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WEProductProfit in storage Update WEProductProfit PUT /admin/v1/w-e-product-profits/${param0} */
export async function putAdminV1WEProductProfitsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WEProductProfitsIdParams,
  body: API.WEProductProfit,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WEProductProfit; message?: string }>(
    `/admin/v1/w-e-product-profits/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WEProductProfit from storage Delete WEProductProfit DELETE /admin/v1/w-e-product-profits/${param0} */
export async function deleteAdminV1WEProductProfitsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WEProductProfitsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-e-product-profits/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
