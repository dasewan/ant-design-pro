// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the riskitem. Get all GDRiskItem GET /admin/v1/g-d-risk-item-enum */
export async function getAdminV1GDRiskItemEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GDRiskItemEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.ANRiskItemCat[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-d-risk-item-enum', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Get a listing of the riskitem. Get all GDRiskItem GET /admin/v1/g-d-risk-item-enum2 */
export async function getAdminV1GDRiskItemEnum2(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GDRiskItemEnum2Params,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GDRiskItem[]; total?: number; message?: string }>(
    '/admin/v1/g-d-risk-item-enum2',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the GDRiskItems. Get all GDRiskItems GET /admin/v1/g-d-risk-items */
export async function getAdminV1GDRiskItems(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GDRiskItemsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GDRiskItem[]; total?: number; message?: string }>(
    '/admin/v1/g-d-risk-items',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GDRiskItem in storage Store GDRiskItem POST /admin/v1/g-d-risk-items */
export async function postAdminV1GDRiskItems(
  body: API.GDRiskItem,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GDRiskItem; message?: string }>(
    '/admin/v1/g-d-risk-items',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Update the specified GDRiskItem in storage Update GDRiskItem PUT /admin/v1/g-d-risk-items-releted_count */
export async function putAdminV1GDRiskItemsReletedCount(options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.GDRiskItem; message?: string }>(
    '/admin/v1/g-d-risk-items-releted_count',
    {
      method: 'PUT',
      ...(options || {}),
    },
  );
}

/** Display the specified GDRiskItem Get GDRiskItem GET /admin/v1/g-d-risk-items/${param0} */
export async function getAdminV1GDRiskItemsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GDRiskItemsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GDRiskItem; message?: string }>(
    `/admin/v1/g-d-risk-items/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GDRiskItem in storage Update GDRiskItem PUT /admin/v1/g-d-risk-items/${param0} */
export async function putAdminV1GDRiskItemsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GDRiskItemsIdParams,
  body: API.GDRiskItem,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GDRiskItem; message?: string }>(
    `/admin/v1/g-d-risk-items/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GDRiskItem from storage Delete GDRiskItem DELETE /admin/v1/g-d-risk-items/${param0} */
export async function deleteAdminV1GDRiskItemsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GDRiskItemsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-d-risk-items/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
