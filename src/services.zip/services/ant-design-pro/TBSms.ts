// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the TBSms. Get all TBSms GET /admin/v1/t-b-sms */
export async function getAdminV1TBSms(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TBSmsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TBSms[]; total?: number; message?: string }>(
    '/admin/v1/t-b-sms',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created TBSms in storage Store TBSms POST /admin/v1/t-b-sms */
export async function postAdminV1TBSms(body: API.TBSms, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.TBSms; message?: string }>('/admin/v1/t-b-sms', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified TBSms Get TBSms GET /admin/v1/t-b-sms/${param0} */
export async function getAdminV1TBSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1TBSmsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TBSms; message?: string }>(
    `/admin/v1/t-b-sms/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified TBSms in storage Update TBSms PUT /admin/v1/t-b-sms/${param0} */
export async function putAdminV1TBSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1TBSmsIdParams,
  body: API.TBSms,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.TBSms; message?: string }>(
    `/admin/v1/t-b-sms/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified TBSms from storage Delete TBSms DELETE /admin/v1/t-b-sms/${param0} */
export async function deleteAdminV1TBSmsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1TBSmsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/t-b-sms/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
