// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the QVerifyItems. Get all QVerifyItems GET /admin/v1/q-verify-items */
export async function getAdminV1QVerifyItems(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1QVerifyItemsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.QVerifyItem[]; total?: number; message?: string }>(
    '/admin/v1/q-verify-items',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created QVerifyItem in storage Store QVerifyItem POST /admin/v1/q-verify-items */
export async function postAdminV1QVerifyItems(
  body: API.QVerifyItem,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.QVerifyItem; message?: string }>(
    '/admin/v1/q-verify-items',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Update the specified QVerifyItem sort in storage Update QVerifyItem PUT /admin/v1/q-verify-items-sort */
export async function putAdminV1QVerifyItemsSort(
  body: API.QVerifyItem,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.QVerifyItem; message?: string }>(
    '/admin/v1/q-verify-items-sort',
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified QVerifyItem Get QVerifyItem GET /admin/v1/q-verify-items/${param0} */
export async function getAdminV1QVerifyItemsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1QVerifyItemsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.QVerifyItem; message?: string }>(
    `/admin/v1/q-verify-items/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified QVerifyItem in storage Update QVerifyItem PUT /admin/v1/q-verify-items/${param0} */
export async function putAdminV1QVerifyItemsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1QVerifyItemsIdParams,
  body: API.QVerifyItem,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.QVerifyItem; message?: string }>(
    `/admin/v1/q-verify-items/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified QVerifyItem from storage Delete QVerifyItem DELETE /admin/v1/q-verify-items/${param0} */
export async function deleteAdminV1QVerifyItemsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1QVerifyItemsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/q-verify-items/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
