// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the DCBorrowRiskDetails. Get all DCBorrowRiskDetails GET /admin/v1/d-c-borrow-risk-details */
export async function getAdminV1DCBorrowRiskDetails(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DCBorrowRiskDetailsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.DCBorrowRiskDetail[];
    total?: number;
    message?: string;
  }>('/admin/v1/d-c-borrow-risk-details', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created DCBorrowRiskDetail in storage Store DCBorrowRiskDetail POST /admin/v1/d-c-borrow-risk-details */
export async function postAdminV1DCBorrowRiskDetails(
  body: API.DCBorrowRiskDetail,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.DCBorrowRiskDetail; message?: string }>(
    '/admin/v1/d-c-borrow-risk-details',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified DCBorrowRiskDetail Get DCBorrowRiskDetail GET /admin/v1/d-c-borrow-risk-details/${param0} */
export async function getAdminV1DCBorrowRiskDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DCBorrowRiskDetailsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DCBorrowRiskDetail; message?: string }>(
    `/admin/v1/d-c-borrow-risk-details/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified DCBorrowRiskDetail in storage Update DCBorrowRiskDetail PUT /admin/v1/d-c-borrow-risk-details/${param0} */
export async function putAdminV1DCBorrowRiskDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1DCBorrowRiskDetailsIdParams,
  body: API.DCBorrowRiskDetail,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DCBorrowRiskDetail; message?: string }>(
    `/admin/v1/d-c-borrow-risk-details/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified DCBorrowRiskDetail from storage Delete DCBorrowRiskDetail DELETE /admin/v1/d-c-borrow-risk-details/${param0} */
export async function deleteAdminV1DCBorrowRiskDetailsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1DCBorrowRiskDetailsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/d-c-borrow-risk-details/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
