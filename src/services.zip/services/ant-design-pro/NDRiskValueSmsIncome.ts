// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the NDRiskValueSmsIncomes. Get all NDRiskValueSmsIncomes GET /admin/v1/n-d-risk-value-sms-incomes */
export async function getAdminV1NDRiskValueSmsIncomes(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NDRiskValueSmsIncomesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.NDRiskValueSmsIncome[];
    total?: number;
    message?: string;
  }>('/admin/v1/n-d-risk-value-sms-incomes', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created NDRiskValueSmsIncome in storage Store NDRiskValueSmsIncome POST /admin/v1/n-d-risk-value-sms-incomes */
export async function postAdminV1NDRiskValueSmsIncomes(
  body: API.NDRiskValueSmsIncome,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.NDRiskValueSmsIncome; message?: string }>(
    '/admin/v1/n-d-risk-value-sms-incomes',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified NDRiskValueSmsIncome Get NDRiskValueSmsIncome GET /admin/v1/n-d-risk-value-sms-incomes/${param0} */
export async function getAdminV1NDRiskValueSmsIncomesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NDRiskValueSmsIncomesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NDRiskValueSmsIncome; message?: string }>(
    `/admin/v1/n-d-risk-value-sms-incomes/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified NDRiskValueSmsIncome in storage Update NDRiskValueSmsIncome PUT /admin/v1/n-d-risk-value-sms-incomes/${param0} */
export async function putAdminV1NDRiskValueSmsIncomesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1NDRiskValueSmsIncomesIdParams,
  body: API.NDRiskValueSmsIncome,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NDRiskValueSmsIncome; message?: string }>(
    `/admin/v1/n-d-risk-value-sms-incomes/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified NDRiskValueSmsIncome from storage Delete NDRiskValueSmsIncome DELETE /admin/v1/n-d-risk-value-sms-incomes/${param0} */
export async function deleteAdminV1NDRiskValueSmsIncomesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1NDRiskValueSmsIncomesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/n-d-risk-value-sms-incomes/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
