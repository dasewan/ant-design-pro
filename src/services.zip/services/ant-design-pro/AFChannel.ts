// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the AFChannels. Get all AFChannels GET /admin/v1/a-f-channels */
export async function getAdminV1AFChannels(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AFChannelsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AFChannel[]; total?: number; message?: string }>(
    '/admin/v1/a-f-channels',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created AFChannel in storage Store AFChannel POST /admin/v1/a-f-channels */
export async function postAdminV1AFChannels(body: API.AFChannel, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.AFChannel; message?: string }>(
    '/admin/v1/a-f-channels',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified AFChannel Get AFChannel GET /admin/v1/a-f-channels/${param0} */
export async function getAdminV1AFChannelsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AFChannelsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AFChannel; message?: string }>(
    `/admin/v1/a-f-channels/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified AFChannel in storage Update AFChannel PUT /admin/v1/a-f-channels/${param0} */
export async function putAdminV1AFChannelsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1AFChannelsIdParams,
  body: API.AFChannel,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AFChannel; message?: string }>(
    `/admin/v1/a-f-channels/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified AFChannel from storage Delete AFChannel DELETE /admin/v1/a-f-channels/${param0} */
export async function deleteAdminV1AFChannelsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1AFChannelsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/a-f-channels/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Get a listing of the Users. Get all AFChannel GET /admin/v1/channels-enum */
export async function getAdminV1ChannelsEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ChannelsEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AFChannel[]; total?: number; message?: string }>(
    '/admin/v1/channels-enum',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
