// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BIPaymentChannels. Get all BIPaymentChannels GET /admin/v1/b-i-payment-channels */
export async function getAdminV1BIPaymentChannels(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BIPaymentChannelsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BIPaymentChannel[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-i-payment-channels', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BIPaymentChannel in storage Store BIPaymentChannel POST /admin/v1/b-i-payment-channels */
export async function postAdminV1BIPaymentChannels(
  body: API.BIPaymentChannel,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BIPaymentChannel; message?: string }>(
    '/admin/v1/b-i-payment-channels',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BIPaymentChannel Get BIPaymentChannel GET /admin/v1/b-i-payment-channels/${param0} */
export async function getAdminV1BIPaymentChannelsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BIPaymentChannelsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BIPaymentChannel; message?: string }>(
    `/admin/v1/b-i-payment-channels/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BIPaymentChannel in storage Update BIPaymentChannel PUT /admin/v1/b-i-payment-channels/${param0} */
export async function putAdminV1BIPaymentChannelsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BIPaymentChannelsIdParams,
  body: API.BIPaymentChannel,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BIPaymentChannel; message?: string }>(
    `/admin/v1/b-i-payment-channels/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BIPaymentChannel from storage Delete BIPaymentChannel DELETE /admin/v1/b-i-payment-channels/${param0} */
export async function deleteAdminV1BIPaymentChannelsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BIPaymentChannelsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-i-payment-channels/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
