// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the ASRiskValueSmsSuspiciouses. Get all ASRiskValueSmsSuspiciouses GET /admin/v1/a-s-risk-value-sms-suspiciouses */
export async function getAdminV1ASRiskValueSmsSuspiciouses(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ASRiskValueSmsSuspiciousesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.ASRiskValueSmsSuspicious[];
    total?: number;
    message?: string;
  }>('/admin/v1/a-s-risk-value-sms-suspiciouses', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created ASRiskValueSmsSuspicious in storage Store ASRiskValueSmsSuspicious POST /admin/v1/a-s-risk-value-sms-suspiciouses */
export async function postAdminV1ASRiskValueSmsSuspiciouses(
  body: API.ASRiskValueSmsSuspicious,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.ASRiskValueSmsSuspicious; message?: string }>(
    '/admin/v1/a-s-risk-value-sms-suspiciouses',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified ASRiskValueSmsSuspicious Get ASRiskValueSmsSuspicious GET /admin/v1/a-s-risk-value-sms-suspiciouses/${param0} */
export async function getAdminV1ASRiskValueSmsSuspiciousesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ASRiskValueSmsSuspiciousesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ASRiskValueSmsSuspicious; message?: string }>(
    `/admin/v1/a-s-risk-value-sms-suspiciouses/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified ASRiskValueSmsSuspicious in storage Update ASRiskValueSmsSuspicious PUT /admin/v1/a-s-risk-value-sms-suspiciouses/${param0} */
export async function putAdminV1ASRiskValueSmsSuspiciousesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1ASRiskValueSmsSuspiciousesIdParams,
  body: API.ASRiskValueSmsSuspicious,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ASRiskValueSmsSuspicious; message?: string }>(
    `/admin/v1/a-s-risk-value-sms-suspiciouses/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified ASRiskValueSmsSuspicious from storage Delete ASRiskValueSmsSuspicious DELETE /admin/v1/a-s-risk-value-sms-suspiciouses/${param0} */
export async function deleteAdminV1ASRiskValueSmsSuspiciousesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1ASRiskValueSmsSuspiciousesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/a-s-risk-value-sms-suspiciouses/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
