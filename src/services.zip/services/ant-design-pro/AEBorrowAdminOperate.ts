// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the AEBorrowAdminOperates. Get all AEBorrowAdminOperates GET /aEBorrowAdminOperates */
export async function getAEBorrowAdminOperates(options?: { [key: string]: any }) {
  return request<{
    success?: boolean;
    data?: API.AEBorrowAdminOperate[];
    total?: number;
    message?: string;
  }>('/aEBorrowAdminOperates', {
    method: 'GET',
    ...(options || {}),
  });
}

/** Store a newly created AEBorrowAdminOperate in storage Store AEBorrowAdminOperate POST /aEBorrowAdminOperates */
export async function postAEBorrowAdminOperates(
  body: API.AEBorrowAdminOperate,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.AEBorrowAdminOperate; message?: string }>(
    '/aEBorrowAdminOperates',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified AEBorrowAdminOperate Get AEBorrowAdminOperate GET /aEBorrowAdminOperates/${param0} */
export async function getAEBorrowAdminOperatesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAEBorrowAdminOperatesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AEBorrowAdminOperate; message?: string }>(
    `/aEBorrowAdminOperates/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified AEBorrowAdminOperate in storage Update AEBorrowAdminOperate PUT /aEBorrowAdminOperates/${param0} */
export async function putAEBorrowAdminOperatesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAEBorrowAdminOperatesIdParams,
  body: API.AEBorrowAdminOperate,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AEBorrowAdminOperate; message?: string }>(
    `/aEBorrowAdminOperates/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified AEBorrowAdminOperate from storage Delete AEBorrowAdminOperate DELETE /aEBorrowAdminOperates/${param0} */
export async function deleteAEBorrowAdminOperatesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAEBorrowAdminOperatesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/aEBorrowAdminOperates/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
