// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the NFSmsContacts. Get all NFSmsContacts GET /admin/v1/n-f-sms-contacts */
export async function getAdminV1NFSmsContacts(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NFSmsContactsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.NFSmsContact[];
    total?: number;
    message?: string;
  }>('/admin/v1/n-f-sms-contacts', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created NFSmsContact in storage Store NFSmsContact POST /admin/v1/n-f-sms-contacts */
export async function postAdminV1NFSmsContacts(
  body: API.NFSmsContact,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.NFSmsContact; message?: string }>(
    '/admin/v1/n-f-sms-contacts',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified NFSmsContact Get NFSmsContact GET /admin/v1/n-f-sms-contacts/${param0} */
export async function getAdminV1NFSmsContactsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NFSmsContactsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NFSmsContact; message?: string }>(
    `/admin/v1/n-f-sms-contacts/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified NFSmsContact in storage Update NFSmsContact PUT /admin/v1/n-f-sms-contacts/${param0} */
export async function putAdminV1NFSmsContactsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1NFSmsContactsIdParams,
  body: API.NFSmsContact,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NFSmsContact; message?: string }>(
    `/admin/v1/n-f-sms-contacts/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified NFSmsContact from storage Delete NFSmsContact DELETE /admin/v1/n-f-sms-contacts/${param0} */
export async function deleteAdminV1NFSmsContactsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1NFSmsContactsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/n-f-sms-contacts/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
