// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WBProductOverdues. Get all WBProductOverdues GET /admin/v1/w-b-product-overdues */
export async function getAdminV1WBProductOverdues(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WBProductOverduesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.WBProductOverdue[];
    total?: number;
    message?: string;
  }>('/admin/v1/w-b-product-overdues', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created WBProductOverdue in storage Store WBProductOverdue POST /admin/v1/w-b-product-overdues */
export async function postAdminV1WBProductOverdues(
  body: API.WBProductOverdue,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.WBProductOverdue; message?: string }>(
    '/admin/v1/w-b-product-overdues',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified WBProductOverdue Get WBProductOverdue GET /admin/v1/w-b-product-overdues/${param0} */
export async function getAdminV1WBProductOverduesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WBProductOverduesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WBProductOverdue; message?: string }>(
    `/admin/v1/w-b-product-overdues/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WBProductOverdue in storage Update WBProductOverdue PUT /admin/v1/w-b-product-overdues/${param0} */
export async function putAdminV1WBProductOverduesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WBProductOverduesIdParams,
  body: API.WBProductOverdue,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WBProductOverdue; message?: string }>(
    `/admin/v1/w-b-product-overdues/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WBProductOverdue from storage Delete WBProductOverdue DELETE /admin/v1/w-b-product-overdues/${param0} */
export async function deleteAdminV1WBProductOverduesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WBProductOverduesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-b-product-overdues/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
