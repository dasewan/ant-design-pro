// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the AKReasons. Get all AKReasons GET /admin/v1/aKReasons */
export async function getAdminV1AKReasons(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AKReasonsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AKReason[]; total?: number; message?: string }>(
    '/admin/v1/aKReasons',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created AKReason in storage Store AKReason POST /admin/v1/aKReasons */
export async function postAdminV1AKReasons(body: API.AKReason, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.AKReason; message?: string }>(
    '/admin/v1/aKReasons',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified AKReason Get AKReason GET /admin/v1/aKReasons/${param0} */
export async function getAdminV1AKReasonsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1AKReasonsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AKReason; message?: string }>(
    `/admin/v1/aKReasons/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified AKReason in storage Update AKReason PUT /admin/v1/aKReasons/${param0} */
export async function putAdminV1AKReasonsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1AKReasonsIdParams,
  body: API.AKReason,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.AKReason; message?: string }>(
    `/admin/v1/aKReasons/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified AKReason from storage Delete AKReason DELETE /admin/v1/aKReasons/${param0} */
export async function deleteAdminV1AKReasonsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1AKReasonsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/aKReasons/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
