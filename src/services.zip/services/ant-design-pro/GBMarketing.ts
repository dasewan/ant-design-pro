// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GBMarketings. Get all GBMarketings GET /admin/v1/g-b-marketings */
export async function getAdminV1GBMarketings(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GBMarketingsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GBMarketing[]; total?: number; message?: string }>(
    '/admin/v1/g-b-marketings',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GBMarketing in storage Store GBMarketing POST /admin/v1/g-b-marketings */
export async function postAdminV1GBMarketings(
  body: API.GBMarketing,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GBMarketing; message?: string }>(
    '/admin/v1/g-b-marketings',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GBMarketing Get GBMarketing GET /admin/v1/g-b-marketings/${param0} */
export async function getAdminV1GBMarketingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GBMarketingsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GBMarketing; message?: string }>(
    `/admin/v1/g-b-marketings/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GBMarketing in storage Update GBMarketing PUT /admin/v1/g-b-marketings/${param0} */
export async function putAdminV1GBMarketingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GBMarketingsIdParams,
  body: API.GBMarketing,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GBMarketing; message?: string }>(
    `/admin/v1/g-b-marketings/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GBMarketing from storage Delete GBMarketing DELETE /admin/v1/g-b-marketings/${param0} */
export async function deleteAdminV1GBMarketingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GBMarketingsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-b-marketings/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
