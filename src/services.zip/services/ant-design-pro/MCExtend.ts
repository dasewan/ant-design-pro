// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the MCExtends. Get all MCExtends GET /admin/v1/m-c-extends */
export async function getAdminV1MCExtends(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MCExtendsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MCExtend[]; total?: number; message?: string }>(
    '/admin/v1/m-c-extends',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created MCExtend in storage Store MCExtend POST /admin/v1/m-c-extends */
export async function postAdminV1MCExtends(body: API.MCExtend, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.MCExtend; message?: string }>(
    '/admin/v1/m-c-extends',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified MCExtend Get MCExtend GET /admin/v1/m-c-extends/${param0} */
export async function getAdminV1MCExtendsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1MCExtendsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MCExtend; message?: string }>(
    `/admin/v1/m-c-extends/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified MCExtend in storage Update MCExtend PUT /admin/v1/m-c-extends/${param0} */
export async function putAdminV1MCExtendsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1MCExtendsIdParams,
  body: API.MCExtend,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.MCExtend; message?: string }>(
    `/admin/v1/m-c-extends/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified MCExtend from storage Delete MCExtend DELETE /admin/v1/m-c-extends/${param0} */
export async function deleteAdminV1MCExtendsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1MCExtendsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/m-c-extends/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
