// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the NBCollectionGroupRoles. Get all NBCollectionGroupRoles GET /admin/v1/n-b-collection-group-roles */
export async function getAdminV1NBCollectionGroupRoles(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NBCollectionGroupRolesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.NBCollectionGroupRole[];
    total?: number;
    message?: string;
  }>('/admin/v1/n-b-collection-group-roles', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created NBCollectionGroupRole in storage Store NBCollectionGroupRole POST /admin/v1/n-b-collection-group-roles */
export async function postAdminV1NBCollectionGroupRoles(
  body: API.NBCollectionGroupRole,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.NBCollectionGroupRole; message?: string }>(
    '/admin/v1/n-b-collection-group-roles',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified NBCollectionGroupRole Get NBCollectionGroupRole GET /admin/v1/n-b-collection-group-roles/${param0} */
export async function getAdminV1NBCollectionGroupRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NBCollectionGroupRolesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NBCollectionGroupRole; message?: string }>(
    `/admin/v1/n-b-collection-group-roles/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified NBCollectionGroupRole in storage Update NBCollectionGroupRole PUT /admin/v1/n-b-collection-group-roles/${param0} */
export async function putAdminV1NBCollectionGroupRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1NBCollectionGroupRolesIdParams,
  body: API.NBCollectionGroupRole,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NBCollectionGroupRole; message?: string }>(
    `/admin/v1/n-b-collection-group-roles/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified NBCollectionGroupRole from storage Delete NBCollectionGroupRole DELETE /admin/v1/n-b-collection-group-roles/${param0} */
export async function deleteAdminV1NBCollectionGroupRolesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1NBCollectionGroupRolesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/n-b-collection-group-roles/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
