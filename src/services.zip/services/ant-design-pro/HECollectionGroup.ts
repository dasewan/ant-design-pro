// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the HECollectionGroups. Get all HECollectionGroups GET /admin/v1/h-e-collection-groups */
export async function getAdminV1HECollectionGroups(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HECollectionGroupsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.HECollectionGroup[];
    total?: number;
    message?: string;
  }>('/admin/v1/h-e-collection-groups', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created HECollectionGroup in storage Store HECollectionGroup POST /admin/v1/h-e-collection-groups */
export async function postAdminV1HECollectionGroups(
  body: API.HECollectionGroup,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.HECollectionGroup; message?: string }>(
    '/admin/v1/h-e-collection-groups',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the HECollectionGroup. Get all HECollectionGroup GET /admin/v1/h-e-collection-groups-enum */
export async function getAdminV1HECollectionGroupsEnum(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HECollectionGroupsEnumParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.HECollectionGroup[];
    total?: number;
    message?: string;
  }>('/admin/v1/h-e-collection-groups-enum', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Display the specified HECollectionGroup Get HECollectionGroup GET /admin/v1/h-e-collection-groups/${param0} */
export async function getAdminV1HECollectionGroupsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HECollectionGroupsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HECollectionGroup; message?: string }>(
    `/admin/v1/h-e-collection-groups/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified HECollectionGroup in storage Update HECollectionGroup PUT /admin/v1/h-e-collection-groups/${param0} */
export async function putAdminV1HECollectionGroupsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1HECollectionGroupsIdParams,
  body: API.HECollectionGroup,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HECollectionGroup; message?: string }>(
    `/admin/v1/h-e-collection-groups/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified HECollectionGroup from storage Delete HECollectionGroup DELETE /admin/v1/h-e-collection-groups/${param0} */
export async function deleteAdminV1HECollectionGroupsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1HECollectionGroupsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/h-e-collection-groups/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
