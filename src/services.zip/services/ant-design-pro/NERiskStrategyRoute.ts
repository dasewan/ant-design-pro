// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the NERiskStrategyRoutes. Get all NERiskStrategyRoutes GET /admin/v1/n-e-risk-strategy-routes */
export async function getAdminV1NERiskStrategyRoutes(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NERiskStrategyRoutesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.NERiskStrategyRoute[];
    total?: number;
    message?: string;
  }>('/admin/v1/n-e-risk-strategy-routes', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created NERiskStrategyRoute in storage Store NERiskStrategyRoute POST /admin/v1/n-e-risk-strategy-routes */
export async function postAdminV1NERiskStrategyRoutes(
  body: API.NERiskStrategyRoute,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.NERiskStrategyRoute; message?: string }>(
    '/admin/v1/n-e-risk-strategy-routes',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Get a listing of the NERiskStrategyRoute. Get all NERiskStrategyRoute GET /admin/v1/n-e-risk-strategy-routes-enums */
export async function getAdminV1NERiskStrategyRoutesEnums(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NERiskStrategyRoutesEnumsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.NERiskStrategyRoute[];
    total?: number;
    message?: string;
  }>('/admin/v1/n-e-risk-strategy-routes-enums', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Update the specified NERiskStrategyRoute sort in storage Update NERiskStrategyRoute PUT /admin/v1/n-e-risk-strategy-routes-sort */
export async function putAdminV1NERiskStrategyRoutesSort(
  body: API.NERiskStrategyRoute,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.NERiskStrategyRoute; message?: string }>(
    '/admin/v1/n-e-risk-strategy-routes-sort',
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified NERiskStrategyRoute Get NERiskStrategyRoute GET /admin/v1/n-e-risk-strategy-routes/${param0} */
export async function getAdminV1NERiskStrategyRoutesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1NERiskStrategyRoutesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NERiskStrategyRoute; message?: string }>(
    `/admin/v1/n-e-risk-strategy-routes/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified NERiskStrategyRoute in storage Update NERiskStrategyRoute PUT /admin/v1/n-e-risk-strategy-routes/${param0} */
export async function putAdminV1NERiskStrategyRoutesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1NERiskStrategyRoutesIdParams,
  body: API.NERiskStrategyRoute,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.NERiskStrategyRoute; message?: string }>(
    `/admin/v1/n-e-risk-strategy-routes/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified NERiskStrategyRoute from storage Delete NERiskStrategyRoute DELETE /admin/v1/n-e-risk-strategy-routes/${param0} */
export async function deleteAdminV1NERiskStrategyRoutesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1NERiskStrategyRoutesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/n-e-risk-strategy-routes/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
