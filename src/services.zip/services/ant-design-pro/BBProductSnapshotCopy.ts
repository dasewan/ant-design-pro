// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BBProductSnapshotCopies. Get all BBProductSnapshotCopies GET /admin/v1/b-b-product-snapshot-copies */
export async function getAdminV1BBProductSnapshotCopies(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BBProductSnapshotCopiesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BBProductSnapshotCopy[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-b-product-snapshot-copies', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BBProductSnapshotCopy in storage Store BBProductSnapshotCopy POST /admin/v1/b-b-product-snapshot-copies */
export async function postAdminV1BBProductSnapshotCopies(
  body: API.BBProductSnapshotCopy,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BBProductSnapshotCopy; message?: string }>(
    '/admin/v1/b-b-product-snapshot-copies',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BBProductSnapshotCopy Get BBProductSnapshotCopy GET /admin/v1/b-b-product-snapshot-copies/${param0} */
export async function getAdminV1BBProductSnapshotCopiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BBProductSnapshotCopiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BBProductSnapshotCopy; message?: string }>(
    `/admin/v1/b-b-product-snapshot-copies/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BBProductSnapshotCopy in storage Update BBProductSnapshotCopy PUT /admin/v1/b-b-product-snapshot-copies/${param0} */
export async function putAdminV1BBProductSnapshotCopiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BBProductSnapshotCopiesIdParams,
  body: API.BBProductSnapshotCopy,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BBProductSnapshotCopy; message?: string }>(
    `/admin/v1/b-b-product-snapshot-copies/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BBProductSnapshotCopy from storage Delete BBProductSnapshotCopy DELETE /admin/v1/b-b-product-snapshot-copies/${param0} */
export async function deleteAdminV1BBProductSnapshotCopiesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BBProductSnapshotCopiesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-b-product-snapshot-copies/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
