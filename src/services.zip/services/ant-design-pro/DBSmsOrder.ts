// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the DBSmsOrders. Get all DBSmsOrders GET /admin/v1/d-b-sms-orders */
export async function getAdminV1DBSmsOrders(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBSmsOrdersParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBSmsOrder[]; total?: number; message?: string }>(
    '/admin/v1/d-b-sms-orders',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created DBSmsOrder in storage Store DBSmsOrder POST /admin/v1/d-b-sms-orders */
export async function postAdminV1DBSmsOrders(
  body: API.DBSmsOrder,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.DBSmsOrder; message?: string }>(
    '/admin/v1/d-b-sms-orders',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified DBSmsOrder Get DBSmsOrder GET /admin/v1/d-b-sms-orders/${param0} */
export async function getAdminV1DBSmsOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1DBSmsOrdersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBSmsOrder; message?: string }>(
    `/admin/v1/d-b-sms-orders/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified DBSmsOrder in storage Update DBSmsOrder PUT /admin/v1/d-b-sms-orders/${param0} */
export async function putAdminV1DBSmsOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1DBSmsOrdersIdParams,
  body: API.DBSmsOrder,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.DBSmsOrder; message?: string }>(
    `/admin/v1/d-b-sms-orders/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified DBSmsOrder from storage Delete DBSmsOrder DELETE /admin/v1/d-b-sms-orders/${param0} */
export async function deleteAdminV1DBSmsOrdersId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1DBSmsOrdersIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/d-b-sms-orders/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
