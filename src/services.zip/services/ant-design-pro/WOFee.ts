// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the WOFees. Get all WOFees GET /admin/v1/w-o-fees */
export async function getAdminV1WOFees(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WOFeesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WOFee[]; total?: number; message?: string }>(
    '/admin/v1/w-o-fees',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created WOFee in storage Store WOFee POST /admin/v1/w-o-fees */
export async function postAdminV1WOFees(body: API.WOFee, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.WOFee; message?: string }>('/admin/v1/w-o-fees', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified WOFee Get WOFee GET /admin/v1/w-o-fees/${param0} */
export async function getAdminV1WOFeesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1WOFeesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WOFee; message?: string }>(
    `/admin/v1/w-o-fees/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified WOFee in storage Update WOFee PUT /admin/v1/w-o-fees/${param0} */
export async function putAdminV1WOFeesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1WOFeesIdParams,
  body: API.WOFee,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.WOFee; message?: string }>(
    `/admin/v1/w-o-fees/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified WOFee from storage Delete WOFee DELETE /admin/v1/w-o-fees/${param0} */
export async function deleteAdminV1WOFeesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1WOFeesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/w-o-fees/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
