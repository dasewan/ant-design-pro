// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the ARReviewAdmins. Get all ARReviewAdmins GET /admin/v1/a-r-review-admins */
export async function getAdminV1ARReviewAdmins(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ARReviewAdminsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.ARReviewAdmin[];
    total?: number;
    message?: string;
  }>('/admin/v1/a-r-review-admins', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created ARReviewAdmin in storage Store ARReviewAdmin POST /admin/v1/a-r-review-admins */
export async function postAdminV1ARReviewAdmins(
  body: API.ARReviewAdmin,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.ARReviewAdmin; message?: string }>(
    '/admin/v1/a-r-review-admins',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Update the specified ARReviewAdmin in storage Update ARReviewAdmin PUT /admin/v1/a-r-review-admins-release */
export async function putAdminV1ARReviewAdminsRelease(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1ARReviewAdminsReleaseParams,
  body: API.ARReviewAdmin,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ARReviewAdmin; message?: string }>(
    '/admin/v1/a-r-review-admins-release',
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified ARReviewAdmin Get ARReviewAdmin GET /admin/v1/a-r-review-admins/${param0} */
export async function getAdminV1ARReviewAdminsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ARReviewAdminsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ARReviewAdmin; message?: string }>(
    `/admin/v1/a-r-review-admins/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified ARReviewAdmin in storage Update ARReviewAdmin PUT /admin/v1/a-r-review-admins/${param0} */
export async function putAdminV1ARReviewAdminsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1ARReviewAdminsIdParams,
  body: API.ARReviewAdmin,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ARReviewAdmin; message?: string }>(
    `/admin/v1/a-r-review-admins/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified ARReviewAdmin from storage Delete ARReviewAdmin DELETE /admin/v1/a-r-review-admins/${param0} */
export async function deleteAdminV1ARReviewAdminsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1ARReviewAdminsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/a-r-review-admins/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
