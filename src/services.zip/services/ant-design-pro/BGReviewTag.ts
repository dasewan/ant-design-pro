// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BGReviewTags. Get all BGReviewTags GET /admin/v1/b-g-review-tags */
export async function getAdminV1BGReviewTags(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BGReviewTagsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BGReviewTag[]; total?: number; message?: string }>(
    '/admin/v1/b-g-review-tags',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created BGReviewTag in storage Store BGReviewTag POST /admin/v1/b-g-review-tags */
export async function postAdminV1BGReviewTags(
  body: API.BGReviewTag,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BGReviewTag; message?: string }>(
    '/admin/v1/b-g-review-tags',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BGReviewTag Get BGReviewTag GET /admin/v1/b-g-review-tags/${param0} */
export async function getAdminV1BGReviewTagsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BGReviewTagsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BGReviewTag; message?: string }>(
    `/admin/v1/b-g-review-tags/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BGReviewTag in storage Update BGReviewTag PUT /admin/v1/b-g-review-tags/${param0} */
export async function putAdminV1BGReviewTagsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BGReviewTagsIdParams,
  body: API.BGReviewTag,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BGReviewTag; message?: string }>(
    `/admin/v1/b-g-review-tags/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BGReviewTag from storage Delete BGReviewTag DELETE /admin/v1/b-g-review-tags/${param0} */
export async function deleteAdminV1BGReviewTagsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BGReviewTagsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-g-review-tags/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
