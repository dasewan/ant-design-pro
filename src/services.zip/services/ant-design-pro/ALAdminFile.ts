// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the ALAdminFiles. Get all ALAdminFiles GET /admin/v1/aLAdminFiles */
export async function getAdminV1ALAdminFiles(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ALAdminFilesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ALAdminFile[]; total?: number; message?: string }>(
    '/admin/v1/aLAdminFiles',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created ALAdminFile in storage Store ALAdminFile POST /admin/v1/aLAdminFiles */
export async function postAdminV1ALAdminFiles(
  body: API.ALAdminFile,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.ALAdminFile; message?: string }>(
    '/admin/v1/aLAdminFiles',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified ALAdminFile Get ALAdminFile GET /admin/v1/aLAdminFiles_templete/${param0} */
export async function getAdminV1ALAdminFilesTempleteName(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ALAdminFilesTempleteNameParams,
  options?: { [key: string]: any },
) {
  const { name: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ALAdminFile; message?: string }>(
    `/admin/v1/aLAdminFiles_templete/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Display the specified ALAdminFile Get ALAdminFile GET /admin/v1/aLAdminFiles/${param0} */
export async function getAdminV1ALAdminFilesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ALAdminFilesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ALAdminFile; message?: string }>(
    `/admin/v1/aLAdminFiles/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified ALAdminFile in storage Update ALAdminFile PUT /admin/v1/aLAdminFiles/${param0} */
export async function putAdminV1ALAdminFilesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1ALAdminFilesIdParams,
  body: API.ALAdminFile,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ALAdminFile; message?: string }>(
    `/admin/v1/aLAdminFiles/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified ALAdminFile from storage Delete ALAdminFile DELETE /admin/v1/aLAdminFiles/${param0} */
export async function deleteAdminV1ALAdminFilesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1ALAdminFilesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/aLAdminFiles/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Display the specified ALAdminFile Get ALAdminFile GET /admin/v1/channels-download/${param0} */
export async function getAdminV1ChannelsDownloadId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1ChannelsDownloadIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.ALAdminFile; message?: string }>(
    `/admin/v1/channels-download/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
