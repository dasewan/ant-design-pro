// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the HAPaymentChannelBanks. Get all HAPaymentChannelBanks GET /admin/v1/h-a-payment-channel-banks */
export async function getAdminV1HAPaymentChannelBanks(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HAPaymentChannelBanksParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.HAPaymentChannelBank[];
    total?: number;
    message?: string;
  }>('/admin/v1/h-a-payment-channel-banks', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created HAPaymentChannelBank in storage Store HAPaymentChannelBank POST /admin/v1/h-a-payment-channel-banks */
export async function postAdminV1HAPaymentChannelBanks(
  body: API.HAPaymentChannelBank,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.HAPaymentChannelBank; message?: string }>(
    '/admin/v1/h-a-payment-channel-banks',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified HAPaymentChannelBank Get HAPaymentChannelBank GET /admin/v1/h-a-payment-channel-banks/${param0} */
export async function getAdminV1HAPaymentChannelBanksId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1HAPaymentChannelBanksIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HAPaymentChannelBank; message?: string }>(
    `/admin/v1/h-a-payment-channel-banks/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified HAPaymentChannelBank in storage Update HAPaymentChannelBank PUT /admin/v1/h-a-payment-channel-banks/${param0} */
export async function putAdminV1HAPaymentChannelBanksId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1HAPaymentChannelBanksIdParams,
  body: API.HAPaymentChannelBank,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.HAPaymentChannelBank; message?: string }>(
    `/admin/v1/h-a-payment-channel-banks/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified HAPaymentChannelBank from storage Delete HAPaymentChannelBank DELETE /admin/v1/h-a-payment-channel-banks/${param0} */
export async function deleteAdminV1HAPaymentChannelBanksId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1HAPaymentChannelBanksIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/h-a-payment-channel-banks/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
