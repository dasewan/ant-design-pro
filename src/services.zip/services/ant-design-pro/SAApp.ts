// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the SAApps. Get all SAApps GET /admin/v1/s-a-apps */
export async function getAdminV1SAApps(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1SAAppsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.SAApp[]; total?: number; message?: string }>(
    '/admin/v1/s-a-apps',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created SAApp in storage Store SAApp POST /admin/v1/s-a-apps */
export async function postAdminV1SAApps(body: API.SAApp, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.SAApp; message?: string }>('/admin/v1/s-a-apps', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** Display the specified SAApp Get SAApp GET /admin/v1/s-a-apps/${param0} */
export async function getAdminV1SAAppsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1SAAppsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.SAApp; message?: string }>(
    `/admin/v1/s-a-apps/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified SAApp in storage Update SAApp PUT /admin/v1/s-a-apps/${param0} */
export async function putAdminV1SAAppsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1SAAppsIdParams,
  body: API.SAApp,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.SAApp; message?: string }>(
    `/admin/v1/s-a-apps/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified SAApp from storage Delete SAApp DELETE /admin/v1/s-a-apps/${param0} */
export async function deleteAdminV1SAAppsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1SAAppsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/s-a-apps/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
