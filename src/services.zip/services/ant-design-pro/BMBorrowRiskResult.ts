// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the BMBorrowRiskResults. Get all BMBorrowRiskResults GET /admin/v1/b-m-borrow-risk-results */
export async function getAdminV1BMBorrowRiskResults(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BMBorrowRiskResultsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.BMBorrowRiskResult[];
    total?: number;
    message?: string;
  }>('/admin/v1/b-m-borrow-risk-results', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created BMBorrowRiskResult in storage Store BMBorrowRiskResult POST /admin/v1/b-m-borrow-risk-results */
export async function postAdminV1BMBorrowRiskResults(
  body: API.BMBorrowRiskResult,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.BMBorrowRiskResult; message?: string }>(
    '/admin/v1/b-m-borrow-risk-results',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified BMBorrowRiskResult Get BMBorrowRiskResult GET /admin/v1/b-m-borrow-risk-results/${param0} */
export async function getAdminV1BMBorrowRiskResultsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1BMBorrowRiskResultsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BMBorrowRiskResult; message?: string }>(
    `/admin/v1/b-m-borrow-risk-results/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified BMBorrowRiskResult in storage Update BMBorrowRiskResult PUT /admin/v1/b-m-borrow-risk-results/${param0} */
export async function putAdminV1BMBorrowRiskResultsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1BMBorrowRiskResultsIdParams,
  body: API.BMBorrowRiskResult,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.BMBorrowRiskResult; message?: string }>(
    `/admin/v1/b-m-borrow-risk-results/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified BMBorrowRiskResult from storage Delete BMBorrowRiskResult DELETE /admin/v1/b-m-borrow-risk-results/${param0} */
export async function deleteAdminV1BMBorrowRiskResultsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1BMBorrowRiskResultsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/b-m-borrow-risk-results/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
