// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GHSettings. Get all GHSettings GET /admin/v1/g-h-settings */
export async function getAdminV1GHSettings(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GHSettingsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GHSetting[]; total?: number; message?: string }>(
    '/admin/v1/g-h-settings',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created GHSetting in storage Store GHSetting POST /admin/v1/g-h-settings */
export async function postAdminV1GHSettings(body: API.GHSetting, options?: { [key: string]: any }) {
  return request<{ success?: boolean; data?: API.GHSetting; message?: string }>(
    '/admin/v1/g-h-settings',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GHSetting Get GHSetting GET /admin/v1/g-h-settings/${param0} */
export async function getAdminV1GHSettingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GHSettingsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GHSetting; message?: string }>(
    `/admin/v1/g-h-settings/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GHSetting in storage Update GHSetting PUT /admin/v1/g-h-settings/${param0} */
export async function putAdminV1GHSettingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GHSettingsIdParams,
  body: API.GHSetting,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GHSetting; message?: string }>(
    `/admin/v1/g-h-settings/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GHSetting from storage Delete GHSetting DELETE /admin/v1/g-h-settings/${param0} */
export async function deleteAdminV1GHSettingsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GHSettingsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-h-settings/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
