// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the GORiskValueSmsSlopes. Get all GORiskValueSmsSlopes GET /admin/v1/g-o-risk-value-sms-slopes */
export async function getAdminV1GORiskValueSmsSlopes(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GORiskValueSmsSlopesParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{
    success?: boolean;
    data?: API.GORiskValueSmsSlope[];
    total?: number;
    message?: string;
  }>('/admin/v1/g-o-risk-value-sms-slopes', {
    method: 'GET',
    params: { ...queryParams },
    ...(options || {}),
  });
}

/** Store a newly created GORiskValueSmsSlope in storage Store GORiskValueSmsSlope POST /admin/v1/g-o-risk-value-sms-slopes */
export async function postAdminV1GORiskValueSmsSlopes(
  body: API.GORiskValueSmsSlope,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.GORiskValueSmsSlope; message?: string }>(
    '/admin/v1/g-o-risk-value-sms-slopes',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified GORiskValueSmsSlope Get GORiskValueSmsSlope GET /admin/v1/g-o-risk-value-sms-slopes/${param0} */
export async function getAdminV1GORiskValueSmsSlopesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1GORiskValueSmsSlopesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GORiskValueSmsSlope; message?: string }>(
    `/admin/v1/g-o-risk-value-sms-slopes/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified GORiskValueSmsSlope in storage Update GORiskValueSmsSlope PUT /admin/v1/g-o-risk-value-sms-slopes/${param0} */
export async function putAdminV1GORiskValueSmsSlopesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1GORiskValueSmsSlopesIdParams,
  body: API.GORiskValueSmsSlope,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.GORiskValueSmsSlope; message?: string }>(
    `/admin/v1/g-o-risk-value-sms-slopes/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified GORiskValueSmsSlope from storage Delete GORiskValueSmsSlope DELETE /admin/v1/g-o-risk-value-sms-slopes/${param0} */
export async function deleteAdminV1GORiskValueSmsSlopesId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1GORiskValueSmsSlopesIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/g-o-risk-value-sms-slopes/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
