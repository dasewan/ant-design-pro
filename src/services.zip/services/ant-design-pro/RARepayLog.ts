// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

/** Get a listing of the RARepayLogs. Get all RARepayLogs GET /admin/v1/r-a-repay-logs */
export async function getAdminV1RARepayLogs(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1RARepayLogsParams,
  options?: { [key: string]: any },
) {
  const { foo: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.RARepayLog[]; total?: number; message?: string }>(
    '/admin/v1/r-a-repay-logs',
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Store a newly created RARepayLog in storage Store RARepayLog POST /admin/v1/r-a-repay-logs */
export async function postAdminV1RARepayLogs(
  body: API.RARepayLog,
  options?: { [key: string]: any },
) {
  return request<{ success?: boolean; data?: API.RARepayLog; message?: string }>(
    '/admin/v1/r-a-repay-logs',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      data: body,
      ...(options || {}),
    },
  );
}

/** Display the specified RARepayLog Get RARepayLog GET /admin/v1/r-a-repay-logs/${param0} */
export async function getAdminV1RARepayLogsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getAdminV1RARepayLogsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.RARepayLog; message?: string }>(
    `/admin/v1/r-a-repay-logs/${param0}`,
    {
      method: 'GET',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}

/** Update the specified RARepayLog in storage Update RARepayLog PUT /admin/v1/r-a-repay-logs/${param0} */
export async function putAdminV1RARepayLogsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.putAdminV1RARepayLogsIdParams,
  body: API.RARepayLog,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: API.RARepayLog; message?: string }>(
    `/admin/v1/r-a-repay-logs/${param0}`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      params: { ...queryParams },
      data: body,
      ...(options || {}),
    },
  );
}

/** Remove the specified RARepayLog from storage Delete RARepayLog DELETE /admin/v1/r-a-repay-logs/${param0} */
export async function deleteAdminV1RARepayLogsId(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.deleteAdminV1RARepayLogsIdParams,
  options?: { [key: string]: any },
) {
  const { id: param0, ...queryParams } = params;
  return request<{ success?: boolean; data?: string; message?: string }>(
    `/admin/v1/r-a-repay-logs/${param0}`,
    {
      method: 'DELETE',
      params: { ...queryParams },
      ...(options || {}),
    },
  );
}
